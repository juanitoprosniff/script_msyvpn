#!/bin/bash

# BadVPN Auto-Installer - Compatible con Ubuntu 22+
# Puertos: 7300, 7200, 7400, 7500
# Usa systemd en lugar de rc.local

# Función para verificar e instalar badvpn-udpgw
install_badvpn() {
    if [[ ! -e /bin/badvpn-udpgw ]]; then
        echo "Descargando badvpn-udpgw..."
        wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null
        chmod 755 /bin/badvpn-udpgw
        echo "✓ badvpn-udpgw instalado correctamente"
    else
        echo "✓ badvpn-udpgw ya está instalado"
    fi
}

# Función para detener procesos existentes
stop_existing_badvpn() {
    echo "Deteniendo procesos BadVPN existentes..."
    killall badvpn-udpgw >/dev/null 2>&1
    pkill -f "badvpn-udpgw" >/dev/null 2>&1
    
    # Detener servicios systemd si existen
    for port in 7300 7200 7400 7500; do
        systemctl stop badvpn-$port.service >/dev/null 2>&1
        systemctl disable badvpn-$port.service >/dev/null 2>&1
    done
    
    sleep 2
}

# Función para crear servicio systemd para cada puerto
create_systemd_service() {
    local port=$1
    
    cat > /etc/systemd/system/badvpn-$port.service << EOF
[Unit]
Description=BadVPN UDP Gateway en puerto $port
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart=/bin/badvpn-udpgw --listen-addr 127.0.0.1:$port --max-clients 1000 --max-connections-for-client 10
Restart=always
RestartSec=3
StandardOutput=null
StandardError=null

[Install]
WantedBy=multi-user.target
EOF

    echo "✓ Servicio creado para puerto $port"
}

# Función para iniciar servicios systemd
start_systemd_services() {
    local ports=(7300 7200 7400 7500)
    
    echo ""
    echo "Creando servicios systemd..."
    
    for port in "${ports[@]}"; do
        create_systemd_service $port
    done
    
    # Recargar systemd
    systemctl daemon-reload
    
    echo ""
    echo "Iniciando servicios..."
    
    for port in "${ports[@]}"; do
        systemctl enable badvpn-$port.service >/dev/null 2>&1
        systemctl start badvpn-$port.service
        sleep 1
    done
}

# Función para verificar el estado
check_status() {
    echo ""
    echo "=== VERIFICANDO ESTADO DE BADVPN ==="
    
    local ports=(7300 7200 7400 7500)
    local active_count=0
    
    for port in "${ports[@]}"; do
        if systemctl is-active --quiet badvpn-$port.service; then
            echo "✓ Puerto $port: ACTIVO"
            active_count=$((active_count + 1))
        else
            echo "✗ Puerto $port: INACTIVO"
        fi
    done
    
    echo ""
    if [[ $active_count -eq 4 ]]; then
        echo "✓ INSTALACIÓN EXITOSA - Todos los puertos BadVPN están activos"
        echo "✓ Puertos activos: 7300, 7200, 7400, 7500"
        echo "✓ Configurado para inicio automático en reinicio"
        echo ""
        echo "Comandos útiles:"
        echo "  - Ver estado: systemctl status badvpn-7300"
        echo "  - Reiniciar: systemctl restart badvpn-7300"
        echo "  - Ver logs: journalctl -u badvpn-7300 -f"
    elif [[ $active_count -gt 0 ]]; then
        echo "⚠ INSTALACIÓN PARCIAL - $active_count/4 puertos activos"
    else
        echo "✗ INSTALACIÓN FALLIDA - Ningún puerto activo"
        echo "Verifica los logs con: journalctl -xe"
    fi
    echo "=================================="
}

# Función para mostrar menú de opciones
show_menu() {
    echo ""
    echo "=== OPCIONES ADICIONALES ==="
    echo "Para gestionar los servicios:"
    echo ""
    echo "Ver estado de todos los puertos:"
    echo "  systemctl status badvpn-*.service"
    echo ""
    echo "Detener todos los servicios:"
    echo "  systemctl stop badvpn-*.service"
    echo ""
    echo "Reiniciar todos los servicios:"
    echo "  systemctl restart badvpn-*.service"
    echo ""
    echo "Ver logs en tiempo real:"
    echo "  journalctl -u badvpn-7300 -f"
    echo "==========================="
}

# Función principal
main() {
    # Verificar si es root
    if [[ $EUID -ne 0 ]]; then
        echo "Este script debe ejecutarse como root"
        exit 1
    fi
    
    echo "=== BadVPN Auto-Installer (Ubuntu 22+ Compatible) ==="
    echo "Configurando puertos: 7300, 7200, 7400, 7500"
    echo "Método: systemd services"
    echo ""
    
    # Instalar screen si no existe (útil para debugging)
    if ! command -v screen &> /dev/null; then
        echo "Instalando screen..."
        apt-get update -qq &>/dev/null
        apt-get install -y screen &>/dev/null
    fi
    
    # Instalar badvpn si no existe
    install_badvpn
    
    # Detener procesos existentes
    stop_existing_badvpn
    
    # Crear e iniciar servicios systemd
    start_systemd_services
    
    # Esperar un poco para que los servicios se estabilicen
    echo ""
    echo "Esperando inicialización..."
    sleep 3
    
    # Verificar estado
    check_status
    
    # Mostrar menú de opciones
    show_menu
}

# Ejecutar función principal
main