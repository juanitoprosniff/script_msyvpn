#!/bin/bash

# BadVPN Auto-Installer - Instala múltiples puertos automáticamente
# Puertos: 7300, 7200, 7400, 7500

# Función para verificar e instalar badvpn-udpgw
install_badvpn() {
    if [[ ! -e /bin/badvpn-udpgw ]]; then
        echo "Descargando badvpn-udpgw..."
        wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null
        chmod 777 /bin/badvpn-udpgw
        echo "badvpn-udpgw instalado correctamente"
    else
        echo "badvpn-udpgw ya está instalado"
    fi
}

# Función para detener procesos existentes
stop_existing_badvpn() {
    echo "Deteniendo procesos BadVPN existentes..."
    killall badvpn-udpgw >/dev/null 2>&1
    pkill -f "badvpn-udpgw" >/dev/null 2>&1
    sleep 2
}

# Función para iniciar BadVPN en múltiples puertos
start_badvpn_multiport() {
    local ports=(7300 7200 7400 7500)
    
    echo "Iniciando BadVPN en puertos múltiples..."
    
    for port in "${ports[@]}"; do
        echo "Iniciando BadVPN en puerto $port"
        screen -dmS "badvpn_$port" /bin/badvpn-udpgw --listen-addr 127.0.0.1:$port --max-clients 1000 --max-connections-for-client 10
        sleep 1
    done
}

# Función para configurar rc.local para inicio automático
configure_autostart() {
    echo "Configurando inicio automático..."
    
    # Crear rc.local
    cat > /etc/rc.local << 'EOF'
#!/bin/sh -e
# BadVPN Auto-start configuration
# Multiple ports: 7300, 7200, 7400, 7500

# Función para iniciar BadVPN
start_badvpn() {
    # Esperar a que el sistema esté listo
    sleep 10
    
    # Puertos a activar
    ports="7300 7200 7400 7500"
    
    # Iniciar cada puerto
    for port in $ports; do
        screen -dmS "badvpn_$port" /bin/badvpn-udpgw --listen-addr 127.0.0.1:$port --max-clients 1000 --max-connections-for-client 10
        sleep 2
    done
}

# Ejecutar función en background
start_badvpn &

exit 0
EOF

    # Dar permisos de ejecución
    chmod +x /etc/rc.local
    
    # Habilitar y reiniciar el servicio
    systemctl enable rc-local.service &>/dev/null
    systemctl start rc-local.service &>/dev/null
    systemctl restart rc-local.service &>/dev/null
}

# Función para verificar el estado
check_status() {
    echo ""
    echo "=== VERIFICANDO ESTADO DE BADVPN ==="
    
    local ports=(7300 7200 7400 7500)
    local active_count=0
    
    for port in "${ports[@]}"; do
        if pgrep -f "listen-addr.*:$port" >/dev/null; then
            echo "✓ Puerto $port: ACTIVO"
            active_count=$((active_count + 1))
        else
            echo "✗ Puerto $port: INACTIVO"
        fi
    done
    
    echo ""
    if [[ $active_count -eq 4 ]]; then
        echo "✓ INSTALACIÓN EXITOSA - Todos los puertos BadVPN están activos"
        echo "✓ Puertos activos: 7300, 7200, 7400, 7500"
        echo "✓ Configurado para inicio automático en reinicio"
    elif [[ $active_count -gt 0 ]]; then
        echo "⚠ INSTALACIÓN PARCIAL - $active_count/4 puertos activos"
    else
        echo "✗ INSTALACIÓN FALLIDA - Ningún puerto activo"
    fi
    echo "=================================="
}

# Función principal
main() {
    echo "=== BadVPN Auto-Installer ==="
    echo "Configurando puertos: 7300, 7200, 7400, 7500"
    echo ""
    
    # Instalar badvpn si no existe
    install_badvpn
    
    # Detener procesos existentes
    stop_existing_badvpn
    
    # Iniciar BadVPN en múltiples puertos
    start_badvpn_multiport
    
    # Configurar inicio automático
    configure_autostart
    
    # Esperar un poco para que los procesos se estabilicen
    echo "Esperando inicialización..."
    sleep 3
    
    # Verificar estado
    check_status
}

# Ejecutar función principal
main