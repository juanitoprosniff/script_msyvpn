#!/bin/bash
#BadVPN Auto-Install por JuanitoProSniff
clear
clear
declare -A cor=([0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m")
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols" && [[ ! -d ${SCPinst} ]] && exit

# Puertos BadVPN por defecto
PUERTOS_DEFAULT=(7100 7200 7300 7400 7500)

# Función para mostrar puertos activos
mportas() {
    unset portas
    portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" | grep -v "COMMAND" | grep "LISTEN")
    while read port; do
        var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
        [[ "$(echo -e $portas | grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
    done <<<"$portas_var"
    echo -e "$portas"
}

# Función para verificar distribución Ubuntu
verificar_ubuntu() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" ]]; then
            VERSION_NUM=$(echo $VERSION_ID | cut -d. -f1)
            if [[ $VERSION_NUM -ge 18 && $VERSION_NUM -le 25 ]]; then
                echo -e "${cor[4]}Ubuntu $VERSION_ID detectado - Compatible${cor[0]}"
                return 0
            else
                echo -e "${cor[3]}Ubuntu $VERSION_ID detectado - Versión no probada${cor[0]}"
                return 0
            fi
        else
            echo -e "${cor[3]}Sistema operativo: $PRETTY_NAME - Puede funcionar${cor[0]}"
            return 0
        fi
    else
        echo -e "${cor[3]}No se pudo detectar la versión del sistema${cor[0]}"
        return 0
    fi
}

# Función para instalar BadVPN
instalar_badvpn() {
    if [[ ! -e /bin/badvpn-udpgw ]]; then
        echo -e "${cor[3]}Descargando BadVPN...${cor[0]}"
        wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null
        if [[ $? -eq 0 ]]; then
            chmod 777 /bin/badvpn-udpgw
            echo -e "${cor[4]}BadVPN descargado e instalado correctamente${cor[0]}"
        else
            echo -e "${cor[2]}Error al descargar BadVPN, intentando fuente alternativa...${cor[0]}"
            # Fuente alternativa
            wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/JuanitoProSniff/VPS-Tools/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null
            if [[ $? -eq 0 ]]; then
                chmod 777 /bin/badvpn-udpgw
                echo -e "${cor[4]}BadVPN descargado desde fuente alternativa${cor[0]}"
            else
                echo -e "${cor[2]}Error al descargar BadVPN de ambas fuentes${cor[0]}"
                exit 1
            fi
        fi
    else
        echo -e "${cor[4]}BadVPN ya está instalado${cor[0]}"
    fi
}

# Función para crear servicio systemd
crear_servicio_systemd() {
    local puerto=$1
    local servicio="badvpn-$puerto"
    
    cat > /etc/systemd/system/$servicio.service << EOF
[Unit]
Description=BadVPN UDP Gateway en puerto $puerto
After=network.target

[Service]
Type=simple
User=root
ExecStart=/bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto
Restart=always
RestartSec=3
KillMode=mixed

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable $servicio &>/dev/null
    systemctl start $servicio &>/dev/null
    
    if systemctl is-active --quiet $servicio; then
        echo -e "${cor[4]}Servicio $servicio iniciado correctamente${cor[0]}"
        return 0
    else
        echo -e "${cor[2]}Error al iniciar servicio $servicio, usando screen como alternativa${cor[0]}"
        # Alternativa con screen
        screen -dmS badvpn-$puerto /bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto
        sleep 1
        if pgrep -f "badvpn.*:$puerto" > /dev/null; then
            echo -e "${cor[4]}BadVPN iniciado en screen para puerto $puerto${cor[0]}"
            return 0
        else
            return 1
        fi
    fi
}

# Función para configurar rc.local con múltiples puertos
configurar_rclocal() {
    echo -e "${cor[3]}Configurando inicio automático...${cor[0]}"
    
    # Crear backup del rc.local actual
    [[ -f /etc/rc.local ]] && cp /etc/rc.local /etc/rc.local.backup.$(date +%s)
    
    cat > /etc/rc.local << EOF
#!/bin/bash
# BadVPN Multi-Puerto Auto-Start por JuanitoProSniff

# Esperar a que la red esté disponible
sleep 10

# Iniciar BadVPN en múltiples puertos
EOF

    for puerto in "${PUERTOS_DEFAULT[@]}"; do
        echo "screen -dmS badvpn-$puerto /bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto" >> /etc/rc.local
    done
    
    echo "" >> /etc/rc.local
    echo "exit 0" >> /etc/rc.local
    
    chmod +x /etc/rc.local &>/dev/null
    
    # Habilitar rc.local en sistemas systemd
    if systemctl list-unit-files | grep -q rc-local; then
        systemctl enable rc-local.service &>/dev/null
    fi
}

# Función principal de instalación automática
badvpn_auto() {
    echo -e "${cor[3]}   BADVPN AUTO-INSTALLER | BY JUANITOPROSNIFF"
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[0]}Configurando BadVPN automáticamente..."
    echo ""
    
    # Verificar sistema
    verificar_ubuntu
    
    # Instalar BadVPN si no está presente
    instalar_badvpn
    
    # Detener procesos BadVPN existentes
    echo -e "${cor[3]}Deteniendo procesos BadVPN existentes...${cor[0]}"
    pkill -f badvpn &>/dev/null
    killall badvpn-udpgw &>/dev/null 2>&1
    
    # Detener servicios systemd existentes
    for puerto in "${PUERTOS_DEFAULT[@]}"; do
        systemctl stop badvpn-$puerto &>/dev/null
        systemctl disable badvpn-$puerto &>/dev/null
    done
    
    echo -e "${cor[3]}Iniciando BadVPN en múltiples puertos...${cor[0]}"
    
    # Configurar cada puerto
    servicios_activos=0
    for puerto in "${PUERTOS_DEFAULT[@]}"; do
        echo -e "${cor[1]}Configurando puerto $puerto...${cor[0]}"
        
        if crear_servicio_systemd $puerto; then
            ((servicios_activos++))
        fi
        
        sleep 1
    done
    
    # Configurar rc.local como respaldo
    configurar_rclocal
    
    # Configurar iptables/ufw si es necesario
    echo -e "${cor[3]}Configurando firewall...${cor[0]}"
    for puerto in "${PUERTOS_DEFAULT[@]}"; do
        ufw allow $puerto &>/dev/null
    done
    
    # Mostrar resultado
    echo ""
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[4]}BADVPN CONFIGURADO EXITOSAMENTE"
    echo -e "${cor[0]}Puertos configurados: ${cor[4]}${PUERTOS_DEFAULT[*]}"
    
    sleep 2
    
    # Verificar servicios activos
    echo -e "${cor[0]}Estado de los servicios:"
    active_count=0
    for puerto in "${PUERTOS_DEFAULT[@]}"; do
        if systemctl is-active --quiet badvpn-$puerto || pgrep -f "badvpn.*:$puerto" > /dev/null; then
            echo -e "${cor[4]}Puerto $puerto: ACTIVO${cor[0]}"
            ((active_count++))
        else
            echo -e "${cor[2]}Puerto $puerto: INACTIVO${cor[0]}"
        fi
    done
    
    echo ""
    echo -e "${cor[4]}Total de servicios BadVPN activos: $active_count/${#PUERTOS_DEFAULT[@]}"
    echo -e "${cor[3]}Protocolo: UDP Gateway"
    echo -e "${cor[3]}Inicio automático: Habilitado"
    echo -e "${cor[3]}Para verificar: systemctl status badvpn-PUERTO"
    echo -e "${cor[3]}Para ver procesos: ps aux | grep badvpn"
    echo -e "${cor[4]}=================================================="
    
    # Mostrar información adicional
    if [[ -e /etc/VPS-AGN/MEUIPvps ]]; then
        IP="$(cat /etc/VPS-AGN/MEUIPvps)"
    else
        MEU_IP=$(ip addr | grep 'inet' | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -o -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | head -1)
        MEU_IP2=$(wget -qO- ipv4.icanhazip.com 2>/dev/null)
        [[ "$MEU_IP" != "$MEU_IP2" ]] && IP="$MEU_IP2" || IP="$MEU_IP"
        echo "$MEU_IP" > /etc/VPS-AGN/MEUIPvps
    fi
    
    echo ""
    echo -e "${cor[3]}INFORMACIÓN DEL SERVIDOR:"
    echo -e "${cor[0]}IP del servidor: ${cor[4]}$IP"
    echo -e "${cor[0]}Puertos BadVPN: ${cor[4]}${PUERTOS_DEFAULT[*]}"
    echo -e "${cor[0]}Protocolo: ${cor[4]}UDP"
    echo -e "${cor[0]}Configuración completa para OpenVPN"
}

# Ejecutar instalación automática
badvpn_auto