#!/bin/bash
# =================================================================================
# BadVPN Auto Installer para MSY Script
# Instala BadVPN con múltiples puertos automáticamente (7200, 7300, 7400, 7500)
# Compatible con Ubuntu 18.04+ y Debian 9+
# =================================================================================

clear

# Colores para mensajes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Función para mostrar mensajes con colores
msg() {
  case $1 in
  -verd) echo -e "${GREEN}$2${NC}" ;;
  -verm) echo -e "${RED}$2${NC}" ;;
  -ama) echo -e "${YELLOW}$2${NC}" ;;
  -azu) echo -e "${CYAN}$2${NC}" ;;
  -bar) echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" ;;
  esac
}

# Función para mostrar título
show_title() {
  msg -bar
  echo -e "${WHITE}           BADVPN AUTO INSTALLER - MSY SCRIPT${NC}"
  msg -bar
}

# Función para verificar si el sistema es compatible
check_system() {
  msg -ama "Verificando compatibilidad del sistema..."
  
  if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    distro=$ID
    version=$VERSION_ID
  else
    msg -verm "No se pudo detectar el sistema operativo"
    exit 1
  fi
  
  case "$distro" in
    ubuntu)
      if [[ $(echo "$version >= 18.04" | bc -l 2>/dev/null) -eq 1 ]]; then
        msg -verd "✓ Ubuntu $version detectado - Compatible"
      else
        msg -verm "✗ Ubuntu $version no es compatible (requiere 18.04+)"
        exit 1
      fi
      ;;
    debian)
      if [[ "$version" -ge 9 ]]; then
        msg -verd "✓ Debian $version detectado - Compatible"
      else
        msg -verm "✗ Debian $version no es compatible (requiere 9+)"
        exit 1
      fi
      ;;
    *)
      msg -ama "⚠ Sistema $distro detectado - Procediendo con precaución"
      ;;
  esac
}

# Función para instalar dependencias
install_dependencies() {
  msg -ama "Instalando dependencias necesarias..."
  
  # Actualizar repositorios
  apt update &>/dev/null
  
  # Instalar paquetes necesarios
  local packages="wget curl screen systemd lsof"
  for package in $packages; do
    if ! dpkg -l | grep -q "^ii  $package "; then
      msg -ama "Instalando $package..."
      if apt install -y $package &>/dev/null; then
        msg -verd "✓ $package instalado"
      else
        msg -verm "✗ Error instalando $package"
      fi
    else
      msg -verd "✓ $package ya está instalado"
    fi
  done
}

# Función para descargar BadVPN
download_badvpn() {
  msg -ama "Descargando BadVPN UDP Gateway..."
  
  # Crear directorio si no existe
  mkdir -p /bin
  
  # URLs de descarga (en orden de preferencia)
  urls=(
    "https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw"
    "https://github.com/ambrop72/badvpn/releases/download/1.999.130/badvpn-udpgw"
  )
  
  for url in "${urls[@]}"; do
    msg -ama "Intentando descargar desde: $url"
    if wget -O /bin/badvpn-udpgw "$url" --timeout=30 --tries=3 &>/dev/null; then
      chmod 755 /bin/badvpn-udpgw
      msg -verd "✓ BadVPN descargado exitosamente"
      return 0
    else
      msg -verm "✗ Descarga falló desde $url"
    fi
  done
  
  # Si falla la descarga directa, instalar desde repositorio
  msg -ama "Instalando BadVPN desde repositorio del sistema..."
  if apt install -y badvpn &>/dev/null; then
    # Buscar el binario instalado
    local badvpn_path=$(which badvpn-udpgw 2>/dev/null)
    if [[ -n "$badvpn_path" ]]; then
      cp "$badvpn_path" /bin/badvpn-udpgw 2>/dev/null
      chmod 755 /bin/badvpn-udpgw
      msg -verd "✓ BadVPN instalado desde repositorio"
      return 0
    fi
  fi
  
  msg -verm "✗ Error: No se pudo instalar BadVPN"
  return 1
}

# Función para detener procesos existentes
stop_existing_processes() {
  msg -ama "Deteniendo procesos existentes de BadVPN..."
  
  # Detener todos los procesos de badvpn
  pkill -f badvpn-udpgw 2>/dev/null
  killall badvpn-udpgw 2>/dev/null
  
  # Esperar un poco
  sleep 2
  
  # Verificar si aún hay procesos corriendo
  if pgrep -f badvpn-udpgw &>/dev/null; then
    msg -ama "Forzando terminación de procesos persistentes..."
    pkill -9 -f badvpn-udpgw 2>/dev/null
    sleep 1
  fi
  
  # Terminar sesiones de screen relacionadas
  screen -list 2>/dev/null | grep badvpn | awk '{print $1}' | while read session; do
    screen -S "$session" -X quit 2>/dev/null
  done
  
  msg -verd "✓ Procesos existentes detenidos"
}

# Función para iniciar BadVPN en múltiples puertos
start_badvpn_multiport() {
  msg -ama "Iniciando BadVPN en múltiples puertos..."
  
  # Puertos a configurar
  local ports=(7200 7300 7400 7500)
  
  for port in "${ports[@]}"; do
    msg -ama "Iniciando BadVPN en puerto $port..."
    screen -dmS "badvpn$port" /bin/badvpn-udpgw --listen-addr 127.0.0.1:$port --max-clients 1000 --max-connections-for-client 10
    sleep 1
    
    # Verificar que se inició correctamente
    if pgrep -f "127.0.0.1:$port" &>/dev/null; then
      msg -verd "✓ Puerto $port activo"
    else
      msg -verm "✗ Error iniciando puerto $port"
    fi
  done
}

# Función para crear servicio systemd
create_systemd_service() {
  msg -ama "Creando servicio systemd para BadVPN..."
  
  cat > /etc/systemd/system/badvpn-multiport.service << 'EOF'
[Unit]
Description=BadVPN UDP Gateway Multi-Port (MSY Script)
After=network.target

[Service]
Type=forking
User=root
WorkingDirectory=/root

# Comando para iniciar los 4 puertos
ExecStart=/bin/bash -c '\
screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10; \
screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10; \
screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10; \
screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10'

# Comando para detener
ExecStop=/bin/bash -c 'pkill -f badvpn-udpgw; killall badvpn-udpgw'

# Reiniciar si falla
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

  # Habilitar y iniciar el servicio
  systemctl daemon-reload
  systemctl enable badvpn-multiport.service &>/dev/null
  
  msg -verd "✓ Servicio systemd creado"
}

# Función para configurar inicio automático con rc.local
setup_rc_local() {
  msg -ama "Configurando inicio automático con rc.local..."
  
  # Crear o actualizar rc.local
  if [[ ! -f /etc/rc.local ]] || [[ ! -x /etc/rc.local ]]; then
    echo '#!/bin/bash' > /etc/rc.local
    chmod +x /etc/rc.local
  fi
  
  # Limpiar configuraciones anteriores de badvpn
  sed -i '/badvpn/d' /etc/rc.local
  sed -i '/exit 0/d' /etc/rc.local
  
  # Agregar configuración de BadVPN
  cat >> /etc/rc.local << 'EOF'

# BadVPN Multi-Puerto - MSY SCRIPT
/bin/bash -c '
screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10 &
screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10 &
screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10 &
screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10 &
' &

exit 0
EOF

  # Asegurar permisos
  chmod +x /etc/rc.local
  
  # Habilitar rc-local.service si existe
  if systemctl list-unit-files | grep -q rc-local; then
    systemctl enable rc-local.service &>/dev/null
  fi
  
  msg -verd "✓ rc.local configurado"
}

# Función para crear script de gestión
create_management_script() {
  msg -ama "Creando script de gestión..."
  
  cat > /usr/local/bin/badvpn-manager << 'EOF'
#!/bin/bash
# BadVPN Manager - MSY Script

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

case "$1" in
  start)
    echo -e "${YELLOW}Iniciando BadVPN Multi-Puerto...${NC}"
    screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10
    sleep 2
    echo -e "${GREEN}✓ BadVPN iniciado en puertos: 7200, 7300, 7400, 7500${NC}"
    ;;
  stop)
    echo -e "${YELLOW}Deteniendo BadVPN...${NC}"
    pkill -f badvpn-udpgw
    killall badvpn-udpgw 2>/dev/null
    sleep 1
    echo -e "${GREEN}✓ BadVPN detenido${NC}"
    ;;
  restart)
    $0 stop
    sleep 2
    $0 start
    ;;
  status)
    echo -e "${WHITE}=== ESTADO DE BADVPN ===${NC}"
    if pgrep -f badvpn-udpgw > /dev/null; then
        local count=$(ps aux | grep badvpn-udpgw | grep -v grep | wc -l)
        echo -e "${GREEN}✓ BadVPN está corriendo con $count procesos${NC}"
        echo -e "${CYAN}Procesos activos:${NC}"
        ps aux | grep badvpn-udpgw | grep -v grep | while read line; do
            local port=$(echo $line | awk '{print $12}' | cut -d: -f2)
            local pid=$(echo $line | awk '{print $2}')
            echo -e "  ${WHITE}PID: $pid - Puerto: $port${NC}"
        done
    else
        echo -e "${RED}✗ BadVPN no está corriendo${NC}"
    fi
    ;;
  *)
    echo -e "${WHITE}Uso: $0 {start|stop|restart|status}${NC}"
    echo -e "${CYAN}Gestiona BadVPN Multi-Puerto (MSY Script)${NC}"
    exit 1
    ;;
esac
EOF

  chmod +x /usr/local/bin/badvpn-manager
  
  # Crear enlace simbólico para fácil acceso
  ln -sf /usr/local/bin/badvpn-manager /usr/bin/badvpn &>/dev/null
  
  msg -verd "✓ Script de gestión creado: badvpn-manager"
}

# Función para verificar la instalación
verify_installation() {
  msg -ama "Verificando instalación..."
  sleep 3
  
  local running_processes=$(pgrep -f badvpn-udpgw | wc -l)
  local expected_ports=(7200 7300 7400 7500)
  local active_ports=()
  
  # Verificar cada puerto
  for port in "${expected_ports[@]}"; do
    if pgrep -f "127.0.0.1:$port" &>/dev/null; then
      active_ports+=($port)
    fi
  done
  
  if [[ ${#active_ports[@]} -eq ${#expected_ports[@]} ]]; then
    msg -verd "✓ Verificación exitosa: BadVPN corriendo en todos los puertos"
    msg -verd "✓ Puertos activos: ${active_ports[*]}"
    msg -verd "✓ Total de procesos: $running_processes"
    return 0
  elif [[ ${#active_ports[@]} -gt 0 ]]; then
    msg -ama "⚠ Instalación parcial: BadVPN corriendo en ${#active_ports[@]} de ${#expected_ports[@]} puertos"
    msg -ama "Puertos activos: ${active_ports[*]}"
    return 1
  else
    msg -verm "✗ Error: BadVPN no está corriendo en ningún puerto"
    return 2
  fi
}

# Función para mostrar información final
show_final_info() {
  clear
  show_title
  msg -verd "INSTALACIÓN DE BADVPN COMPLETADA"
  msg -bar
  echo -e "${WHITE}Información de la instalación:${NC}"
  echo -e "${CYAN}• Puertos configurados: 7200, 7300, 7400, 7500${NC}"
  echo -e "${CYAN}• Inicio automático: Habilitado${NC}"
  echo -e "${CYAN}• Servicio systemd: badvpn-multiport${NC}"
  echo -e "${CYAN}• Script de gestión: badvpn-manager${NC}"
  msg -bar
  echo -e "${WHITE}Comandos útiles:${NC}"
  echo -e "${GREEN}• badvpn-manager start    ${NC}- Iniciar BadVPN"
  echo -e "${GREEN}• badvpn-manager stop     ${NC}- Detener BadVPN"
  echo -e "${GREEN}• badvpn-manager restart  ${NC}- Reiniciar BadVPN"
  echo -e "${GREEN}• badvpn-manager status   ${NC}- Ver estado"
  echo -e "${GREEN}• systemctl status badvpn-multiport ${NC}- Estado del servicio"
  msg -bar
  
  # Mostrar estado actual
  verify_installation
  msg -bar
}

# Función principal de instalación
main_install() {
  show_title
  msg -ama "Iniciando instalación automática de BadVPN Multi-Puerto"
  msg -ama "Puertos a configurar: 7200, 7300, 7400, 7500"
  msg -bar
  
  # Paso 1: Verificar sistema
  check_system || exit 1
  
  # Paso 2: Instalar dependencias
  install_dependencies
  
  # Paso 3: Descargar BadVPN
  download_badvpn || exit 1
  
  # Paso 4: Detener procesos existentes
  stop_existing_processes
  
  # Paso 5: Iniciar BadVPN en múltiples puertos
  start_badvpn_multiport
  
  # Paso 6: Crear servicio systemd
  create_systemd_service
  
  # Paso 7: Configurar rc.local
  setup_rc_local
  
  # Paso 8: Crear script de gestión
  create_management_script
  
  # Paso 9: Verificar instalación
  local verification_result
  verify_installation
  verification_result=$?
  
  # Paso 10: Mostrar información final
  show_final_info
  
  return $verification_result
}

# Función para mostrar ayuda
show_help() {
  echo -e "${WHITE}BadVPN Auto Installer - MSY Script${NC}"
  echo -e "${CYAN}Uso: $0 [opción]${NC}"
  echo ""
  echo -e "${WHITE}Opciones:${NC}"
  echo -e "${GREEN}  install    ${NC}Instalar BadVPN Multi-Puerto"
  echo -e "${GREEN}  uninstall  ${NC}Desinstalar BadVPN"
  echo -e "${GREEN}  status     ${NC}Mostrar estado de BadVPN"
  echo -e "${GREEN}  --help     ${NC}Mostrar esta ayuda"
  echo ""
  echo -e "${CYAN}Sin argumentos: Ejecuta la instalación automática${NC}"
}

# Función para desinstalar BadVPN
uninstall_badvpn() {
  show_title
  msg -ama "Desinstalando BadVPN Multi-Puerto..."
  msg -bar
  
  # Detener servicio
  systemctl stop badvpn-multiport.service 2>/dev/null
  systemctl disable badvpn-multiport.service 2>/dev/null
  
  # Detener procesos
  pkill -f badvpn-udpgw 2>/dev/null
  killall badvpn-udpgw 2>/dev/null
  
  # Eliminar archivos
  rm -f /etc/systemd/system/badvpn-multiport.service
  rm -f /bin/badvpn-udpgw
  rm -f /usr/local/bin/badvpn-manager
  rm -f /usr/bin/badvpn
  
  # Limpiar rc.local
  sed -i '/badvpn/d' /etc/rc.local 2>/dev/null
  
  # Recargar systemd
  systemctl daemon-reload
  
  msg -verd "✓ BadVPN desinstalado completamente"
  msg -bar
}

# Manejar argumentos de línea de comandos
case "$1" in
  install)
    main_install
    ;;
  uninstall)
    uninstall_badvpn
    ;;
  status)
    if command -v badvpn-manager &>/dev/null; then
      badvpn-manager status
    else
      msg -verm "BadVPN Manager no está instalado"
      exit 1
    fi
    ;;
  --help|-h)
    show_help
    ;;
  "")
    # Sin argumentos, ejecutar instalación automática
    main_install
    ;;
  *)
    msg -verm "Opción no válida: $1"
    show_help
    exit 1
    ;;
esac

exit $?