#!/bin/bash
clear
clear
declare -A cor=([0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m")
SCPdir="/etc/MSY-SCRIPT"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols" && [[ ! -d ${SCPinst} ]] && exit

# Función para mostrar mensajes con colores
msg() {
  BRAN='\033[1;37m' && RED='\e[31m' && GREEN='\e[32m' && YELLOW='\e[33m'
  BLUE='\e[34m' && MAGENTA='\e[35m' && MAG='\033[1;36m' && BLACK='\e[1m' && SEMCOR='\e[0m'
  case $1 in
  -ne) cor="${RED}${BLACK}" && echo -ne "${cor}${2}${SEMCOR}" ;;
  -ama) cor="${YELLOW}${BLACK}" && echo -e "${cor}${2}${SEMCOR}" ;;
  -verm) cor="${YELLOW}${BLACK}[!] ${RED}" && echo -e "${cor}${2}${SEMCOR}" ;;
  -azu) cor="${MAG}${BLACK}" && echo -e "${cor}${2}${SEMCOR}" ;;
  -verd) cor="${GREEN}${BLACK}" && echo -e "${cor}${2}${SEMCOR}" ;;
  -bra) cor="${RED}" && echo -ne "${cor}${2}${SEMCOR}" ;;
  -nazu) cor="${COLOR[6]}${BLACK}" && echo -ne "${cor}${2}${SEMCOR}" ;;
  -gri) cor="\e[5m\033[1;100m" && echo -ne "${cor}${2}${SEMCOR}" ;;
  "-bar2" | "-bar") cor="${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" && echo -e "${SEMCOR}${cor}${SEMCOR}" ;;
  "-tit") echo -e "\e[1;97m           \e[5m\033[1;100m   MSY SCRIPT VPN   \033[1;37m" ;;
  "-verm2") cor="${MAGENTA}${BLACK}" && echo -ne "${cor}${2}${SEMCOR}" ;;
  esac
}

mportas() {
    unset portas
    portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" | grep -v "COMMAND" | grep "LISTEN")
    while read port; do
        var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
        [[ "$(echo -e $portas | grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
    done <<<"$portas_var"
    i=1
    echo -e "$portas"
}

# Función para verificar si BadVPN está corriendo
check_badvpn_status() {
    local running_processes=$(ps aux | grep badvpn-udpgw | grep -v grep | wc -l)
    return $running_processes
}

# Función para mostrar el estado de activación
activado() {
    msg -bar
    check_badvpn_status
    local processes=$?
    if [ $processes -gt 0 ]; then
        msg -verd "              BADVPN ACTIVADO EXITOSAMENTE"
        msg -verd "              PUERTOS ACTIVOS: $(ps aux | grep badvpn-udpgw | grep -v grep | awk '{print $12}' | cut -d: -f2 | tr '\n' ',' | sed 's/,$//')"
    else
        msg -ama "              BADVPN NO ESTÁ CORRIENDO"
    fi
    msg -bar
}

# Función para instalar BadVPN si no existe
install_badvpn() {
    if [[ ! -e /bin/badvpn-udpgw ]]; then
        msg -ama "Descargando BadVPN UDP Gateway..."
        # Intenta múltiples fuentes para la descarga
        if wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null; then
            chmod 777 /bin/badvpn-udpgw
            msg -verd "BadVPN descargado exitosamente"
        elif wget -O /bin/badvpn-udpgw https://github.com/ambrop72/badvpn/releases/download/1.999.130/badvpn-udpgw &>/dev/null; then
            chmod 777 /bin/badvpn-udpgw
            msg -verd "BadVPN descargado exitosamente (fuente alternativa)"
        else
            msg -verm "Error al descargar BadVPN. Instalando desde repositorio..."
            apt update &>/dev/null
            apt install badvpn -y &>/dev/null
            if which badvpn-udpgw &>/dev/null; then
                ln -s $(which badvpn-udpgw) /bin/badvpn-udpgw 2>/dev/null
                chmod 777 /bin/badvpn-udpgw
                msg -verd "BadVPN instalado desde repositorio"
            else
                msg -verm "Error: No se pudo instalar BadVPN"
                return 1
            fi
        fi
    fi
    return 0
}

# Función para detener todos los procesos de BadVPN
stop_all_badvpn() {
    msg -ama "Deteniendo todos los procesos de BadVPN..."
    pkill -f badvpn-udpgw 2>/dev/null
    killall badvpn-udpgw 2>/dev/null
    sleep 2
    
    # Verificar si aún hay procesos corriendo
    if pgrep -f badvpn-udpgw &>/dev/null; then
        msg -ama "Forzando terminación de procesos persistentes..."
        pkill -9 -f badvpn-udpgw 2>/dev/null
        sleep 1
    fi
}

# Función para crear configuración de inicio automático
create_autostart() {
    local ports="$1"
    
    # Crear script de inicio
    cat > /etc/init.d/badvpn << 'EOF'
#!/bin/bash
### BEGIN INIT INFO
# Provides:          badvpn
# Required-Start:    $network $local_fs $remote_fs
# Required-Stop:     $network $local_fs $remote_fs
# Should-Start:      $named
# Should-Stop:       $named
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: BadVPN UDP Gateway
# Description:       BadVPN UDP Gateway for VPN connections
### END INIT INFO

case "$1" in
  start)
    echo "Iniciando BadVPN UDP Gateway..."
    screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10
    screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10
    echo "BadVPN iniciado en puertos 7200, 7300, 7400, 7500"
    ;;
  stop)
    echo "Deteniendo BadVPN UDP Gateway..."
    pkill -f badvpn-udpgw
    killall badvpn-udpgw 2>/dev/null
    echo "BadVPN detenido"
    ;;
  restart)
    $0 stop
    sleep 2
    $0 start
    ;;
  status)
    if pgrep -f badvpn-udpgw > /dev/null; then
        echo "BadVPN está corriendo"
        ps aux | grep badvpn-udpgw | grep -v grep
    else
        echo "BadVPN no está corriendo"
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status}"
    exit 1
    ;;
esac

exit 0
EOF
    
    chmod +x /etc/init.d/badvpn
    
    # Habilitar el servicio para inicio automático
    if command -v systemctl &>/dev/null; then
        systemctl enable badvpn 2>/dev/null
    else
        update-rc.d badvpn defaults 2>/dev/null
    fi
    
    # Configurar rc.local como respaldo
    if [[ -f /etc/rc.local ]]; then
        # Remover configuraciones anteriores de badvpn
        sed -i '/badvpn/d' /etc/rc.local
        sed -i '/exit 0/d' /etc/rc.local
    fi
    
    cat >> /etc/rc.local << 'EOF'
#!/bin/bash
# BadVPN Multi-Puerto - MSY SCRIPT
screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10
screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10
screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10
screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10
exit 0
EOF
    
    chmod +x /etc/rc.local
    
    # Habilitar rc-local.service si está disponible
    if systemctl list-unit-files | grep -q rc-local; then
        systemctl enable rc-local.service 2>/dev/null
    fi
}

# Función principal de BadVPN con múltiples puertos automáticos
BadVPN() {
    # Instalar BadVPN si no existe
    if ! install_badvpn; then
        return 1
    fi
    
    msg -bar
    msg -tit
    msg -ama "  \e[1;43m\e[91mBADVPN ACTIVATOR MSY SCRIPT (Multi Puerto)\e[0m"
    msg -bar
    echo -e "$(msg -verd "[1]")$(msg -verm2 "➜ ")$(msg -azu "ACTIVAR BADVPN MULTI-PUERTO (7200,7300,7400,7500)")"
    echo -e "$(msg -verd "[2]")$(msg -verm2 "➜ ")$(msg -azu "AGREGAR PUERTO PERSONALIZADO BADVPN")"
    echo -e "$(msg -verd "[3]")$(msg -verm2 "➜ ")$(msg -azu "DETENER SERVICIO BADVPN")"
    echo -e "$(msg -verd "[4]")$(msg -verm2 "➜ ")$(msg -azu "MOSTRAR ESTADO DE BADVPN")"
    echo -e "$(msg -verd "[0]")$(msg -verm2 "➜ ")$(msg -azu "SALIR")"
    msg -bar
    read -p "Escribe una opción (por defecto 1): " -e -i 1 portasx
    tput cuu1 && tput dl1
    
    case ${portasx} in
        1)
            msg -ama "Activando BadVPN en múltiples puertos..."
            stop_all_badvpn
            sleep 2
            
            # Iniciar BadVPN en múltiples puertos
            screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10
            screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10
            screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10
            screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10
            
            sleep 3
            
            # Crear configuración de inicio automático
            create_autostart "7200,7300,7400,7500"
            
            activado
            ;;
        2)
            read -p " Digite el puerto para BadVPN: " ud
            if [[ "$ud" =~ ^[0-9]+$ ]] && [ "$ud" -ge 1024 ] && [ "$ud" -le 65535 ]; then
                msg -ama "Iniciando BadVPN en puerto $ud..."
                screen -dmS badvpn$ud /bin/badvpn-udpgw --listen-addr 127.0.0.1:$ud --max-clients 1000 --max-connections-for-client 10
                
                # Agregar al rc.local si no existe
                if ! grep -q "127.0.0.1:$ud" /etc/rc.local; then
                    sed -i '/exit 0/d' /etc/rc.local
                    echo "screen -dmS badvpn$ud /bin/badvpn-udpgw --listen-addr 127.0.0.1:$ud --max-clients 1000 --max-connections-for-client 10" >> /etc/rc.local
                    echo "exit 0" >> /etc/rc.local
                fi
                
                sleep 2
                activado
            else
                msg -verm "Puerto inválido. Debe ser un número entre 1024 y 65535."
            fi
            ;;
        3)
            msg -bar
            msg -tit
            msg -ama "          BADVPN DESACTIVADOR (UDP)"
            msg -bar
            stop_all_badvpn
            
            # Limpiar configuraciones de inicio automático
            rm -f /etc/init.d/badvpn
            if command -v systemctl &>/dev/null; then
                systemctl disable badvpn 2>/dev/null
            else
                update-rc.d badvpn remove 2>/dev/null
            fi
            
            # Limpiar rc.local
            sed -i '/badvpn/d' /etc/rc.local
            if ! grep -q "exit 0" /etc/rc.local; then
                echo "exit 0" >> /etc/rc.local
            fi
            
            rm -rf /bin/badvpn-udpgw
            
            check_badvpn_status
            if [ $? -eq 0 ]; then
                msg -verd "                DESACTIVADO EXITOSAMENTE"
            else
                msg -ama "                AÚN HAY PROCESOS CORRIENDO"
            fi
            msg -bar
            ;;
        4)
            msg -bar
            msg -ama "          ESTADO DE BADVPN UDP"
            msg -bar
            check_badvpn_status
            local processes=$?
            if [ $processes -gt 0 ]; then
                msg -verd "BadVPN está corriendo con $processes proceso(s)"
                echo -e "\033[1;37mProcesos activos:\033[0m"
                ps aux | grep badvpn-udpgw | grep -v grep | while read line; do
                    port=$(echo $line | awk '{print $12}' | cut -d: -f2)
                    pid=$(echo $line | awk '{print $2}')
                    msg -azu "PID: $pid - Puerto: $port"
                done
            else
                msg -verm "BadVPN no está corriendo"
            fi
            msg -bar
            read -p "Presiona Enter para continuar..."
            ;;
        0)
            msg -verm "    Saliendo..."
            exit 0
            ;;
        *)
            msg -verm "Opción inválida"
            ;;
    esac
}

# Función para instalación automática (llamada desde el instalador principal)
auto_install() {
    msg -ama "Instalación automática de BadVPN Multi-Puerto..."
    
    if ! install_badvpn; then
        return 1
    fi
    
    stop_all_badvpn
    sleep 2
    
    # Iniciar BadVPN en múltiples puertos automáticamente
    screen -dmS badvpn7200 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7200 --max-clients 1000 --max-connections-for-client 10 &
    screen -dmS badvpn7300 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7300 --max-clients 1000 --max-connections-for-client 10 &
    screen -dmS badvpn7400 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7400 --max-clients 1000 --max-connections-for-client 10 &
    screen -dmS badvpn7500 /bin/badvpn-udpgw --listen-addr 127.0.0.1:7500 --max-clients 1000 --max-connections-for-client 10 &
    
    wait
    sleep 5
    
    # Crear configuración de inicio automático
    create_autostart "7200,7300,7400,7500"
    
    # Verificar instalación
    check_badvpn_status
    local processes=$?
    if [ $processes -gt 0 ]; then
        msg -verd "BadVPN Multi-Puerto instalado exitosamente"
        return 0
    else
        msg -verm "Error en la instalación automática de BadVPN"
        return 1
    fi
}

# Detectar si se ejecuta para instalación automática
if [[ "$1" == "auto" ]]; then
    auto_install
else
    BadVPN
fi