#!/bin/bash
clear
clear
declare -A cor=([0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m")
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols" && [[ ! -d ${SCPinst} ]] && exit

# Puertos BadVPN por defecto
PUERTOS_DEFAULT=(7100 7200 7300 7400 7500)

# Función para mostrar puertos activos
mportas() {
	unset portas
	portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" | grep -v "COMMAND" | grep "LISTEN")
	while read port; do
		var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
		[[ "$(echo -e $portas | grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
	done <<<"$portas_var"
	i=1
	echo -e "$portas"
}

# Función para verificar distribución Ubuntu
verificar_ubuntu() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        if [[ "$ID" == "ubuntu" ]]; then
            VERSION_NUM=$(echo $VERSION_ID | cut -d. -f1)
            if [[ $VERSION_NUM -ge 18 && $VERSION_NUM -le 25 ]]; then
                echo "✓ Ubuntu $VERSION_ID detectado - Compatible"
                return 0
            else
                echo "⚠ Ubuntu $VERSION_ID detectado - Versión no probada"
                return 1
            fi
        else
            echo "⚠ Sistema operativo: $PRETTY_NAME - Puede funcionar"
            return 1
        fi
    else
        echo "⚠ No se pudo detectar la versión del sistema"
        return 1
    fi
}

# Función para verificar activación
activado() {
	msg -bar
	echo -e "${cor[4]}Verificando servicios BadVPN activos...${cor[0]}"
	local servicios_activos=0
	
	for puerto in "${PUERTOS_DEFAULT[@]}"; do
		if [[ "$(ps aux | grep "badvpn.*:$puerto" | grep -v grep)" ]]; then
			echo -e "${cor[4]}✓ BadVPN activo en puerto $puerto${cor[0]}"
			((servicios_activos++))
		fi
	done
	
	if [[ $servicios_activos -gt 0 ]]; then
		msg -verd "            $servicios_activos SERVICIOS BADVPN ACTIVADOS EXITOSAMENTE"
	else
		msg -ama "                 NINGÚN SERVICIO ACTIVO"
	fi
	msg -bar
}

# Función para instalar BadVPN
instalar_badvpn() {
	if [[ ! -e /bin/badvpn-udpgw ]]; then
		echo -e "${cor[3]}Descargando BadVPN...${cor[0]}"
		wget -O /bin/badvpn-udpgw https://raw.githubusercontent.com/khaledagn/VPS-AGN_English_Official/master/LINKS-LIBRARIES/badvpn-udpgw &>/dev/null
		if [[ $? -eq 0 ]]; then
			chmod 777 /bin/badvpn-udpgw
			echo -e "${cor[4]}✓ BadVPN descargado e instalado correctamente${cor[0]}"
		else
			echo -e "${cor[2]}✗ Error al descargar BadVPN${cor[0]}"
			exit 1
		fi
	else
		echo -e "${cor[4]}✓ BadVPN ya está instalado${cor[0]}"
	fi
}

# Función para crear servicio systemd
crear_servicio_systemd() {
	local puerto=$1
	local servicio="badvpn-$puerto"
	
	cat > /etc/systemd/system/$servicio.service << EOF
[Unit]
Description=BadVPN UDP Gateway en puerto $puerto
After=network.target

[Service]
Type=simple
User=root
ExecStart=/bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto
Restart=always
RestartSec=3
KillMode=mixed

[Install]
WantedBy=multi-user.target
EOF

	systemctl daemon-reload
	systemctl enable $servicio &>/dev/null
	systemctl start $servicio &>/dev/null
	
	if systemctl is-active --quiet $servicio; then
		echo -e "${cor[4]}✓ Servicio $servicio iniciado correctamente${cor[0]}"
	else
		echo -e "${cor[2]}✗ Error al iniciar servicio $servicio${cor[0]}"
	fi
}

# Función para activar múltiples puertos
activar_multipuerto() {
	echo -e "${cor[3]}Iniciando BadVPN en múltiples puertos...${cor[0]}"
	
	for puerto in "${PUERTOS_DEFAULT[@]}"; do
		echo -e "${cor[1]}Configurando puerto $puerto...${cor[0]}"
		
		# Detener servicio existente si está corriendo
		systemctl stop badvpn-$puerto &>/dev/null
		
		# Matar procesos existentes en el puerto
		pkill -f "badvpn.*:$puerto" &>/dev/null
		
		# Crear y iniciar servicio
		crear_servicio_systemd $puerto
		
		sleep 1
	done
	
	# Configurar rc.local como respaldo
	configurar_rclocal_multipuerto
}

# Función para configurar rc.local con múltiples puertos
configurar_rclocal_multipuerto() {
	echo -e "${cor[3]}Configurando inicio automático...${cor[0]}"
	
	cat > /etc/rc.local << EOF
#!/bin/bash
# BadVPN Multi-Puerto Auto-Start

# Esperar a que la red esté disponible
sleep 5

# Iniciar BadVPN en múltiples puertos
EOF

	for puerto in "${PUERTOS_DEFAULT[@]}"; do
		echo "screen -dmS badvpn-$puerto /bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto" >> /etc/rc.local
	done
	
	echo "exit 0" >> /etc/rc.local
	
	chmod +x /etc/rc.local &>/dev/null
	
	# Habilitar rc.local en sistemas systemd
	if systemctl list-unit-files | grep -q rc-local; then
		systemctl enable rc-local.service &>/dev/null
		systemctl start rc-local.service &>/dev/null
	fi
}

# Función para activar puerto personalizado
activar_puerto_personalizado() {
	read -p "Ingrese el puerto para BadVPN (ej: 7600): " puerto_custom
	
	# Validar que sea un número
	if ! [[ "$puerto_custom" =~ ^[0-9]+$ ]]; then
		echo -e "${cor[2]}Error: Debe ingresar un número de puerto válido${cor[0]}"
		return 1
	fi
	
	# Validar rango de puertos
	if [[ $puerto_custom -lt 1024 || $puerto_custom -gt 65535 ]]; then
		echo -e "${cor[2]}Error: Puerto debe estar entre 1024 y 65535${cor[0]}"
		return 1
	fi
	
	echo -e "${cor[3]}Configurando BadVPN en puerto $puerto_custom...${cor[0]}"
	
	# Crear servicio systemd
	crear_servicio_systemd $puerto_custom
	
	# Agregar a rc.local
	if ! grep -q "badvpn.*:$puerto_custom" /etc/rc.local; then
		sed -i "/exit 0/i screen -dmS badvpn-$puerto_custom /bin/badvpn-udpgw --listen-addr 127.0.0.1:$puerto_custom" /etc/rc.local
	fi
	
	activado
}

# Función para detener todos los servicios BadVPN
detener_badvpn() {
	msg -bar
	msg -tit
	msg -ama "          DESACTIVADOR BADVPN (UDP MULTI-PUERTO)"
	msg -bar
	
	echo -e "${cor[3]}Deteniendo todos los servicios BadVPN...${cor[0]}"
	
	# Detener servicios systemd
	for puerto in "${PUERTOS_DEFAULT[@]}"; do
		if systemctl is-active --quiet badvpn-$puerto; then
			systemctl stop badvpn-$puerto &>/dev/null
			systemctl disable badvpn-$puerto &>/dev/null
			echo -e "${cor[4]}✓ Servicio badvpn-$puerto detenido${cor[0]}"
		fi
	done
	
	# Matar todos los procesos badvpn
	pkill -f badvpn &>/dev/null
	killall badvpn-udpgw &>/dev/null 2>&1
	
	# Limpiar archivos de servicio
	rm -f /etc/systemd/system/badvpn-*.service
	systemctl daemon-reload
	
	# Limpiar rc.local
	echo -e "#!/bin/bash" > /etc/rc.local
	echo "exit 0" >> /etc/rc.local
	chmod +x /etc/rc.local
	
	# Verificar que no hay procesos activos
	if [[ ! "$(ps aux | grep badvpn | grep -v grep)" ]]; then
		msg -verd "            TODOS LOS SERVICIOS DESACTIVADOS EXITOSAMENTE"
	else
		msg -ama "            ALGUNOS SERVICIOS AÚN ESTÁN ACTIVOS"
	fi
	
	msg -bar
}

# Función para mostrar estado de servicios
mostrar_estado() {
	msg -bar
	msg -tit
	msg -ama "           ESTADO DE SERVICIOS BADVPN"
	msg -bar
	
	echo -e "${cor[3]}Puertos configurados por defecto: ${PUERTOS_DEFAULT[*]}${cor[0]}"
	echo -e ""
	
	for puerto in "${PUERTOS_DEFAULT[@]}"; do
		if systemctl is-active --quiet badvpn-$puerto; then
			echo -e "${cor[4]}Puerto $puerto: ✓ ACTIVO${cor[0]}"
		else
			echo -e "${cor[2]}Puerto $puerto: ✗ INACTIVO${cor[0]}"
		fi
	done
	
	# Mostrar otros procesos badvpn
	echo -e ""
	echo -e "${cor[3]}Procesos BadVPN adicionales:${cor[0]}"
	ps aux | grep badvpn | grep -v grep | while read line; do
		puerto=$(echo $line | grep -o "127\.0\.0\.1:[0-9]*" | cut -d: -f2)
		echo -e "${cor[1]}Puerto $puerto: ACTIVO (proceso)${cor[0]}"
	done
	
	msg -bar
}

# Función principal del menú
BadVPN() {
	# Verificar Ubuntu
	verificar_ubuntu
	
	# Instalar BadVPN si no está presente
	instalar_badvpn
	
	msg -bar
	msg -tit
	msg -ama "  \e[1;43m\e[91mACTIVADOR BADVPN MULTI-PUERTO (Sin Límites)\e[0m"
	msg -bar
	echo -e "$(msg -verd "[1]")$(msg -verm2 " ➤ ")$(msg -azu "ACTIVAR BADVPN MULTI-PUERTO (7100-7500)")"
	echo -e "$(msg -verd "[2]")$(msg -verm2 " ➤ ")$(msg -azu "AGREGAR PUERTO PERSONALIZADO")"
	echo -e "$(msg -verd "[3]")$(msg -verm2 " ➤ ")$(msg -azu "VER ESTADO DE SERVICIOS")"
	echo -e "$(msg -verd "[4]")$(msg -verm2 " ➤ ")$(msg -azu "DETENER TODOS LOS SERVICIOS BADVPN")"
	echo -e "$(msg -verd "[0]")$(msg -verm2 " ➤ ")$(msg -azu "SALIR")"

	msg -bar
	read -p "Seleccione una opción (por defecto 1): " -e -i 1 opcion
	tput cuu1 && tput dl1
	
	case $opcion in
		1)
			activar_multipuerto
			activado
			;;
		2)
			activar_puerto_personalizado
			;;
		3)
			mostrar_estado
			;;
		4)
			detener_badvpn
			;;
		0)
			msg -verm "Saliendo del script..."
			exit 0
			;;
		*)
			msg -verm "Opción no válida"
			BadVPN
			;;
	esac
}

# Ejecutar función principal
BadVPN