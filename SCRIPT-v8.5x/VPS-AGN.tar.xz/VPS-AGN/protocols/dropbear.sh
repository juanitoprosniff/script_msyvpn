#!/bin/bash
# =================================================================
# SCRIPT DE INSTALACIÓN DE DROPBEAR
# Modificado por JuanitoProSniff para compatibilidad con Ubuntu 18-25
# - Fuerza la versión de Dropbear de Ubuntu 20.04 en sistemas 22.04+
# - Banner personalizado y traducción completa al español.
# =================================================================
#25/01/2021

# --- Seccion de funciones auxiliares ---
# (Añadidas para que el script funcione de forma independiente)
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Simula la función de traducción
fun_trans () {
    echo "$2"
}

# Simula las funciones de mensaje
msg-bar() {
    echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}
msg-tit() {
    # No hace nada, es un placeholder
    :
}
# --- Fin de funciones auxiliares ---

# Limpia la pantalla
clear
clear

# Función para listar los puertos en uso
mportas () {
    unset portas
    portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
    while read port; do
        var1=$(echo "$port" | awk '{print $1}') && var2=$(echo "$port" | awk '{print $9}' | awk -F ":" '{print $2}')
        [[ "$(echo -e "$portas"|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
    done <<< "$portas_var"
    i=1
    echo -e "$portas"
}

# Función para mejorar la velocidad de la red (opcional)
fun_eth () {
    eth=$(ifconfig | grep -v inet6 | grep -v lo | grep -v 127.0.0.1 | grep "encap:Ethernet" | awk '{print $1}')
    [[ -n "$eth" ]] && {
    msg-bar
    echo -e "${cor[3]} ¿Aplicar mejoras para optimizar los paquetes SSH?"
    echo -e "${cor[3]} (Opción para usuarios avanzados)"
    msg-bar
    read -p " [S/N]: " -e -i n sshsn
    [[ "$sshsn" = @(s|S|y|Y) ]] && {
        echo -e "${cor[1]} Corrigiendo problemas de paquetes en SSH..."
        echo -e " ¿Cuál es la tasa de RX (recepción)?"
        read -p "[ 1 - 999999999 ]: " -e -i 999999999 rx
        echo -e " ¿Cuál es la tasa de TX (transmisión)?"
        read -p "[ 1 - 999999999 ]: " -e -i 999999999 tx
        apt-get install ethtool -y > /dev/null 2>&1
        ethtool -G "$eth" rx "$rx" tx "$tx" > /dev/null 2>&1
    }
    msg-bar
    }
}

# Barra de progreso animada
fun_bar () {
    comando="$1"
    _=$($comando > /dev/null 2>&1) & > /dev/null
    pid=$!
    while [[ -d /proc/$pid ]]; do
        echo -ne " \033[1;33m["
        for((i=0; i<20; i++)); do
            echo -ne "\033[1;31m##"
            sleep 0.1 # Acelerado para una instalación más rápida
        done
        echo -ne "\033[1;33m]"
        sleep 0.2s
        echo
        tput cuu1 && tput dl1
    done
    echo -ne " \033[1;33m[\033[1;31m########################################\033[1;33m] - \033[1;32m100%\033[0m\n"
    sleep 1s
}

# Función principal para instalar/desinstalar Dropbear
fun_dropbear () {
    # Si Dropbear ya está instalado, ofrece desinstalarlo
    if [[ -e /etc/default/dropbear ]]; then
        msg-bar
        echo -e "\033[1;32m DESINSTALANDO DROPBEAR EXISTENTE"
        msg-bar
        service dropbear stop &> /dev/null
        fun_bar "apt-get remove -y dropbear"
        msg-bar
        echo -e "\033[1;32m Dropbear desinstalado con éxito."
        msg-bar
        [[ -e /etc/default/dropbear ]] && rm /etc/default/dropbear
        return 0
    fi

    # --- Inicio de la instalación ---
    msg-bar
    echo -e "\033[1;32m    INSTALADOR DE DROPBEAR | BY JUANITOPROSNIFF"
    msg-bar
    echo -e "\033[1;31m Selecciona puertos válidos (ej: 80 8080 443)"
    msg-bar
    read -p $'\033[1;31m Escribe los puertos separados por espacios: \033[1;37m' DPORT

    # Valida los puertos ingresados
    PORT=""
    TTOTAL=($DPORT)
    for((i=0; i<${#TTOTAL[@]}; i++)); do
        if [[ -z "$(mportas | grep -w "${TTOTAL[$i]}")" ]]; then
            echo -e "\033[1;33m Puerto elegido:\033[1;32m ${TTOTAL[$i]} ✔ OK"
            PORT="$PORT ${TTOTAL[$i]}"
        else
            echo -e "\033[1;33m Puerto elegido:\033[1;31m ${TTOTAL[$i]} ✖ OCUPADO"
        fi
    done

    # Si no se eligió ningún puerto válido, sale
    [[ -z "$PORT" ]] && {
        echo -e "\033[1;31m No se ha elegido ningún puerto válido. Abortando.\033[0m"
        return 1
    }

    # === LÓGICA DE DETECCIÓN Y FIJACIÓN DE VERSIÓN ===
    # Detecta el sistema operativo de forma moderna y fiable
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        VERSION_ID_MAJOR=$(echo "$VERSION_ID" | cut -d. -f1)
    else
        echo -e "${cor[2]} Error: No se pudo detectar la versión de Ubuntu. Abortando."
        exit 1
    fi

    # Si es Ubuntu 22 o superior, fuerza la versión de Dropbear de Ubuntu 20.04 (focal)
    if [[ "$ID" == "ubuntu" && "$VERSION_ID_MAJOR" -ge 22 ]]; then
        msg-bar
        echo -e "${cor[3]} Ubuntu $VERSION_ID detectado."
        echo -e "${cor[3]} Forzando la instalación de Dropbear v2019.78 (de Ubuntu 20.04)."
        msg-bar
        # Añade el repositorio de Focal y le da prioridad a Dropbear
        echo "deb http://archive.ubuntu.com/ubuntu/ focal main universe" > /etc/apt/sources.list.d/focal-dropbear.list
        cat <<EOF > /etc/apt/preferences.d/focal-dropbear.pref
Package: dropbear
Pin: release n=focal
Pin-Priority: 1001

Package: *
Pin: release n=focal
Pin-Priority: 100
EOF
        apt-get update > /dev/null 2>&1
    fi
    
    # Instalación de Dropbear
    msg-bar
    echo -e "${cor[2]} Instalando Dropbear..."
    msg-bar
    # Usamos --allow-downgrades por si es necesario para la fijación de versión
    fun_bar "apt-get install -y --allow-downgrades dropbear"
    
    # Limpia los archivos de configuración de APT si fueron creados
    if [[ -f /etc/apt/sources.list.d/focal-dropbear.list ]]; then
        rm /etc/apt/sources.list.d/focal-dropbear.list
        rm /etc/apt/preferences.d/focal-dropbear.pref
        apt-get update > /dev/null 2>&1
    fi
    
    # --- Configuración de Dropbear ---
    # Crea el archivo de banner con tu nombre
    echo "Servidor Protegido - By JuanitoProSniff" > /etc/dropbear/banner

    msg-bar
    echo -e "${cor[2]} Configurando Dropbear..."
    msg-bar
    
    # Genera el archivo de configuración de Dropbear
    cat <<EOF > /etc/default/dropbear
NO_START=0
DROPBEAR_EXTRA_ARGS="VAR"
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

    # Añade los puertos a la configuración
    for dpts in $PORT; do
        sed -i "s/VAR/-p $dpts VAR/g" /etc/default/dropbear
    done
    sed -i "s/VAR//g" /etc/default/dropbear

    # Llama a la función de optimización de red
    fun_eth
    
    # Reinicia los servicios para aplicar los cambios
    service ssh restart > /dev/null 2>&1
    service dropbear restart > /dev/null 2>&1

    echo -e "${cor[4]} ¡Dropbear ha sido configurado con ÉXITO!"
    msg-bar
    echo -e "${cor[3]} Puertos abiertos: ${cor[2]}${PORT}"
    msg-bar
}

# Ejecuta la función principal
fun_dropbear
