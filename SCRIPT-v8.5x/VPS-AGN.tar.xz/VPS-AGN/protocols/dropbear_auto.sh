#!/bin/bash
# =================================================================
# SCRIPT DE INSTALACIÓN AUTOMÁTICA DE DROPBEAR (V3 - COMPILADO)
# Modificado por JuanitoProSniff para máxima compatibilidad y personalización.
#
# SOLUCIONES IMPLEMENTADAS:
# 1. Compila Dropbear 2019.78 desde la fuente para control total.
# 2. Modifica IDENT_VERSION_PART a "JuanitoProSniff" en el código fuente.
# 3. Añade el flag "-s" para aceptar usuarios con shell /bin/false.
# 4. Elimina la función "Enhanced" (ethtool) para evitar errores de conexión.
# 5. Elimina el banner.
# =================================================================

clear
clear
# Definición de colores
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Función para listar puertos en uso
mportas () {
    lsof -V -i tcp -P -n | grep -v "ESTABLISHED" | grep -v "COMMAND" | grep "LISTEN"
}

# Barra de progreso
fun_bar () {
    comando="$1"
    _=$($comando > /dev/null 2>&1) & > /dev/null
    pid=$!
    while [[ -d /proc/$pid ]]; do
        echo -ne " \033[1;33m["
        for((i=0; i<20; i++)); do echo -ne "\033[1;31m##"; sleep 0.1; done
        echo -ne "\033[1;33m]"; sleep 0.2s; echo; tput cuu1 && tput dl1
    done
    echo -ne " \033[1;33m[\033[1;31m########################################\033[1;33m] - \033[1;32m100%\033[0m\n"
    sleep 1s
}

# --- FUNCIÓN PRINCIPAL ---
fun_dropbear_compile () {
    # 1. DESINSTALACIÓN PREVIA
    echo -e "${cor[3]}Asegurando una instalación limpia..."
    systemctl stop dropbear dropbear-multi > /dev/null 2>&1
    fun_bar "apt-get purge -y dropbear"
    rm -f /etc/systemd/system/dropbear-multi.service
    systemctl daemon-reload
    echo -e "${cor[4]}Limpieza completada."

    # 2. PUERTOS Y VALIDACIÓN
    echo -e "\033[1;32m   INSTALADOR AUTOMÁTICO DE DROPBEAR | BY JUANITOPROSNIFF"
    DPORT="90 109 110 143"
    PORT=""
    echo -e "${cor[3]}Validando puertos automáticos: $DPORT"
    for puerto in $DPORT; do
        if [[ -z "$(mportas | grep -w ":$puerto")" ]]; then
            echo -e "\033[1;33m Puerto disponible:\033[1;32m $puerto ✔ OK"
            PORT="$PORT $puerto"
        else
            echo -e "\033[1;33m Puerto ocupado:\033[1;31m $puerto ✖ OCUPADO"
        fi
    done
   
    [[ -z "$PORT" ]] && {
        echo -e "\033[1;31m Ninguno de los puertos predefinidos está disponible. Abortando.\033[0m"
        return 1
    }

    # 3. COMPILACIÓN DESDE LA FUENTE
    echo -e "${cor[3]}Instalando dependencias para la compilación..."
    fun_bar "apt-get install -y build-essential gcc make zlib1g-dev"

    echo -e "${cor[3]}Descargando código fuente de Dropbear 2019.78..."
    wget https://matt.ucc.asn.au/dropbear/releases/dropbear-2019.78.tar.bz2 -O dropbear.tar.bz2 > /dev/null 2>&1
    tar -xjf dropbear.tar.bz2
    cd dropbear-2019.78

    echo -e "${cor[3]}Modificando identificador de versión a 'JuanitoProSniff'..."
    # Esta es la línea clave que cambia el nombre de la versión
    sed -i 's/#define IDENT_VERSION_PART "2019.78"/#define IDENT_VERSION_PART "JuanitoProSniff"/' sysoptions.h
    sleep 2

    echo -e "${cor[3]}Compilando e instalando Dropbear..."
    ./configure > /dev/null 2>&1
    make > /dev/null 2>&1
    fun_bar "make install"
    
    cd ..
    rm -rf dropbear-2019.78 dropbear.tar.bz2
    echo -e "${cor[4]}Compilación finalizada."

    # 4. CREACIÓN DEL SERVICIO SYSTEMD
    echo -e "${cor[3]}Creando servicio personalizado para Dropbear..."
    PUERTOS_ARGS=$(echo $PORT | sed 's/ / -p /g' | sed 's/^/-p /')
    
    cat > /etc/systemd/system/dropbear.service << EOF
[Unit]
Description=Dropbear SSH server (Custom Build by JuanitoProSniff)
After=network.target

[Service]
# La bandera -s es la solución para aceptar usuarios con shell /bin/false
# El binario ahora está en /usr/local/sbin/dropbear
ExecStart=/usr/local/sbin/dropbear -s -E -F ${PUERTOS_ARGS}
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

    # 5. INICIO DE SERVICIOS Y FIREWALL
    systemctl daemon-reload
    systemctl enable --now dropbear > /dev/null 2>&1
    service ssh restart > /dev/null 2>&1

    for ufww in $PORT 22; do
        ufw allow "$ufww" > /dev/null 2>&1
    done
    
    # 6. MENSAJE FINAL
    IP=$(wget -qO- ipv4.icanhazip.com)
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[4]}  DROPBEAR COMPILADO E INSTALADO CON ÉXITO"
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[0]} IP del servidor: ${cor[4]}$IP"
    echo -e "${cor[0]} Puertos configurados:"
    for puerto in $PORT; do
        echo -e "${cor[4]}   ✓ Puerto $puerto"
    done
    echo -e "${cor[0]} Versión ID: ${cor[2]}SSH-2.0-dropbear_JuanitoProSniff"
    echo -e "${cor[3]} Para verificar, usa: ${cor[1]}systemctl status dropbear"
    echo -e "${cor[4]}=================================================="
}

# Ejecutar función principal
fun_dropbear_compile
