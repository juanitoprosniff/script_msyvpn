#!/bin/bash
#====================================================================
# DROPBEAR AUTO-INSTALL - VERSIÓN MEJORADA Y OPTIMIZADA
# Modificado por JuanitoProSniff
# Instalación forzada de Dropbear 2019 (Ubuntu 20)
# Puertos: 90, 109, 110, 143
# Alta estabilidad y soporte multi-usuario
# Fecha: 2026 - Optimizado para Ubuntu 20-24 Server
#====================================================================

clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols" && [[ ! -d ${SCPinst} ]] && exit

declare -A cor=( 
    [0]="\033[1;37m" 
    [1]="\033[1;34m" 
    [2]="\033[1;31m" 
    [3]="\033[1;33m" 
    [4]="\033[1;32m" 
)

#====================================================================
# FUNCIÓN: Mostrar puertos en uso
#====================================================================
mportas() {
    unset portas
    portas_var=$(lsof -V -i tcp -P -n 2>/dev/null | grep -v "ESTABLISHED" | grep -v "COMMAND" | grep "LISTEN")
    while read port; do
        var1=$(echo $port | awk '{print $1}') 
        var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
        [[ "$(echo -e $portas | grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
    done <<< "$portas_var"
    echo -e "$portas"
}

#====================================================================
# FUNCIÓN: Verificar si puerto está siendo usado por dropbear
#====================================================================
check_dropbear_port() {
    local puerto=$1
    local dropbear_process=$(lsof -i :$puerto 2>/dev/null | grep dropbear)
    if [[ ! -z "$dropbear_process" ]]; then
        return 0  # Puerto usado por dropbear
    else
        return 1  # Puerto no usado por dropbear
    fi
}

#====================================================================
# FUNCIÓN: Verificar dropbear existente
#====================================================================
check_existing_dropbear() {
    local target_ports="90 109 110 143"
    local configured_ports=""
    local all_configured=true

    if systemctl is-active --quiet dropbear-multi 2>/dev/null; then
        echo -e "${cor[3]}→ Detectado servicio dropbear-multi activo"
        
        for port in $target_ports; do
            if check_dropbear_port $port; then
                echo -e "${cor[4]}  ✓ Puerto $port: Configurado por Dropbear"
                configured_ports="$configured_ports $port"
            else
                echo -e "${cor[2]}  ✗ Puerto $port: No configurado"
                all_configured=false
            fi
        done
        
        if $all_configured; then
            echo -e "${cor[4]}✓ Todos los puertos objetivo ya están configurados"
            return 0
        else
            return 1
        fi
    else
        return 1
    fi
}

#====================================================================
# FUNCIÓN: Obtener IP del servidor
#====================================================================
fun_ip() {
    if [[ -e /etc/VPS-AGN/MEUIPvps ]]; then
        IP="$(cat /etc/VPS-AGN/MEUIPvps)"
    else
        MEU_IP=$(ip addr | grep 'inet' | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -o -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | head -1)
        MEU_IP2=$(curl -s -4 --connect-timeout 3 ifconfig.me 2>/dev/null || wget -qO- --timeout=3 ipv4.icanhazip.com 2>/dev/null)
        [[ "$MEU_IP" != "$MEU_IP2" ]] && IP="$MEU_IP2" || IP="$MEU_IP"
        echo "$MEU_IP" > /etc/VPS-AGN/MEUIPvps
    fi
}

#====================================================================
# FUNCIÓN: Barra de progreso
#====================================================================
fun_bar() {
    comando="$1"
    _=$(
        $comando > /dev/null 2>&1
    ) & > /dev/null
    pid=$!
    while [[ -d /proc/$pid ]]; do
        echo -ne " ${cor[3]}["
        for((i=0; i<20; i++)); do
            echo -ne "${cor[1]}▓"
            sleep 0.05
        done
        echo -ne "${cor[3]}]"
        sleep 0.5
        echo
        tput cuu1 && tput dl1
    done
    echo -ne " ${cor[3]}[${cor[1]}████████████████████████████████████████${cor[3]}] - ${cor[4]}100%${cor[0]}\n"
    sleep 0.5
}

#====================================================================
# FUNCIÓN: Optimización de red para SSH
#====================================================================
optimizar_red() {
    echo -e "${cor[3]}→ Aplicando optimizaciones de red para SSH..."
    
    # Configurar parámetros del kernel para mejor rendimiento
    cat >> /etc/sysctl.conf << EOF

# Optimizaciones para Dropbear SSH - JuanitoProSniff
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 131072
net.core.wmem_default = 131072
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
net.ipv4.tcp_keepalive_time = 600
net.ipv4.tcp_keepalive_intvl = 60
net.ipv4.tcp_keepalive_probes = 10
net.ipv4.tcp_fin_timeout = 30
net.ipv4.tcp_tw_reuse = 1
net.core.netdev_max_backlog = 5000
net.ipv4.tcp_max_syn_backlog = 8192
EOF
    
    sysctl -p > /dev/null 2>&1
    
    # Optimizar interfaz de red si está disponible
    eth=$(ip -o link show | awk -F': ' '{print $2}' | grep -v lo | head -1)
    if [[ ! -z "$eth" ]]; then
        apt-get install -y ethtool &> /dev/null
        ethtool -G $eth rx 4096 tx 4096 2>/dev/null || true
        ethtool -K $eth tso on gso on gro on 2>/dev/null || true
    fi
    
    echo -e "${cor[4]}  ✓ Optimizaciones aplicadas correctamente"
}

#====================================================================
# FUNCIÓN PRINCIPAL: Instalar y configurar Dropbear
#====================================================================
fun_dropbear() {
    clear
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}║    ${cor[3]}DROPBEAR AUTO-INSTALLER MEJORADO${cor[4]}               ║"
    echo -e "${cor[4]}║    ${cor[0]}Por JuanitoProSniff - Versión Optimizada${cor[4]}       ║"
    echo -e "${cor[4]}║    ${cor[0]}Dropbear 2019 (Ubuntu 20) | Multi-Usuario${cor[4]}      ║"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
    echo ""
    echo -e "${cor[3]}Puertos a configurar: ${cor[4]}90, 109, 110, 143${cor[0]}"
    echo ""

    # Verificar si dropbear ya está configurado correctamente
    if check_existing_dropbear; then
        echo ""
        echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
        echo -e "${cor[4]}║  DROPBEAR YA ESTÁ CONFIGURADO CORRECTAMENTE          ║"
        echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
        fun_ip
        echo ""
        echo -e "${cor[0]}IP del servidor:    ${cor[4]}$IP"
        echo -e "${cor[0]}Puertos activos:"
        for puerto in 90 109 110 143; do
            if check_dropbear_port $puerto; then
                echo -e "${cor[4]}  ✓ Puerto $puerto (ACTIVO)"
            fi
        done
        echo -e "${cor[0]}Banner:             ${cor[4]}JuanitoProSniff© - Dropbear SSH Server"
        echo -e "${cor[0]}Verificar estado:   ${cor[3]}systemctl status dropbear-multi"
        echo ""
        echo -e "${cor[4]}✓ INSTALACIÓN COMPLETADA (YA EXISTENTE)${cor[0]}"
        return 0
    fi

    # Si llegamos aquí, necesitamos instalar/reconfigurar
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║  Preparando instalación de Dropbear...    ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    # Remover dropbear anterior si existe
    if [[ -e /etc/default/dropbear ]] || systemctl list-units --full -all | grep -q dropbear; then
        echo -e "${cor[3]}→ Removiendo instalación anterior de Dropbear..."
        systemctl stop dropbear-multi &>/dev/null
        systemctl stop dropbear &>/dev/null
        systemctl disable dropbear &>/dev/null
        systemctl disable dropbear-multi &>/dev/null
        
        apt-get remove --purge dropbear -y &>/dev/null
        apt-get autoremove -y &>/dev/null
        
        rm -f /etc/default/dropbear
        rm -f /etc/systemd/system/dropbear-multi.service
        rm -f /etc/systemd/system/dropbear.service
        rm -rf /etc/dropbear/*
        
        echo -e "${cor[4]}  ✓ Dropbear anterior removido"
    fi

    # Puertos predefinidos
    DPORT="90 109 110 143"
    TTOTAL=($DPORT)
    PORT=""
    OCCUPIED_BY_OTHERS=""

    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║    Verificando disponibilidad de puertos  ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    for((i=0; i<${#TTOTAL[@]}; i++)); do
        port_check=$(mportas | grep "${TTOTAL[$i]}")
        if [[ "$port_check" = "" ]]; then
            echo -e "${cor[4]}✓ Puerto ${TTOTAL[$i]}: Disponible"
            PORT="$PORT ${TTOTAL[$i]}"
        elif check_dropbear_port ${TTOTAL[$i]}; then
            echo -e "${cor[4]}✓ Puerto ${TTOTAL[$i]}: Ya usado por Dropbear"
            PORT="$PORT ${TTOTAL[$i]}"
        else
            echo -e "${cor[2]}✗ Puerto ${TTOTAL[$i]}: Ocupado por otro servicio"
            OCCUPIED_BY_OTHERS="$OCCUPIED_BY_OTHERS ${TTOTAL[$i]}"
        fi
    done
    
    # Verificar que tengamos al menos un puerto disponible
    if [[ -z "$PORT" ]] && [[ ! -z "$OCCUPIED_BY_OTHERS" ]]; then
        echo ""
        echo -e "${cor[2]}═══════════════════════════════════════════════════════"
        echo -e "${cor[2]}ERROR: Ningún puerto válido disponible"
        echo -e "${cor[2]}Todos los puertos están ocupados por otros servicios"
        echo -e "${cor[2]}Puertos ocupados:$OCCUPIED_BY_OTHERS"
        echo -e "${cor[2]}═══════════════════════════════════════════════════════${cor[0]}"
        return 1
    elif [[ -z "$PORT" ]]; then
        echo -e "${cor[2]}ERROR: No se pudieron configurar puertos${cor[0]}"
        return 1
    fi

    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║       Configurando repositorios...         ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    # Detectar versión del sistema
    sysvar=$(lsb_release -rs 2>/dev/null || cat /etc/os-release | grep VERSION_ID | cut -d'"' -f2)
    ubuntu_codename=$(lsb_release -cs 2>/dev/null || cat /etc/os-release | grep VERSION_CODENAME | cut -d'=' -f2)
    
    echo -e "${cor[0]}Sistema detectado: ${cor[4]}Ubuntu $sysvar ($ubuntu_codename)"
    
    # Agregar repositorio de Ubuntu 20.04 (Focal) para Dropbear 2019
    echo -e "${cor[3]}→ Agregando repositorio de Ubuntu 20.04 (Focal) para Dropbear 2019..."
    
    # Backup de sources.list
    cp /etc/apt/sources.list /etc/apt/sources.list.backup.dropbear
    
    # Agregar repositorio focal temporalmente
    cat >> /etc/apt/sources.list << EOF

# Repositorio temporal para Dropbear 2019 (Ubuntu 20.04)
deb http://archive.ubuntu.com/ubuntu focal main universe
EOF
    
    echo -e "${cor[4]}  ✓ Repositorio agregado"

    # Actualizar e instalar Dropbear 2019
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║    Instalando Dropbear 2019 (Ubuntu 20)   ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    echo -e "${cor[3]}→ Actualizando lista de paquetes..."
    apt-get update -qq 2>&1 | grep -v "NO_PUBKEY" | grep -v "Signature" > /dev/null
    
    echo -e "${cor[3]}→ Descargando Dropbear 2019..."
    apt-get install -y --allow-downgrades dropbear=2019.78-2build1 &>/dev/null || \
    apt-get install -y dropbear &>/dev/null
    
    # Verificar instalación
    if ! command -v dropbear &> /dev/null; then
        echo -e "${cor[2]}ERROR: No se pudo instalar Dropbear${cor[0]}"
        return 1
    fi
    
    # Verificar versión
    dropbear_version=$(dropbear -V 2>&1 | head -1)
    echo -e "${cor[4]}  ✓ Dropbear instalado: ${cor[0]}$dropbear_version"
    
    # Restaurar sources.list original y limpiar
    echo -e "${cor[3]}→ Limpiando repositorios temporales..."
    mv /etc/apt/sources.list.backup.dropbear /etc/apt/sources.list
    apt-get update -qq > /dev/null 2>&1
    
    # Marcar paquete para mantener versión
    apt-mark hold dropbear &>/dev/null
    echo -e "${cor[4]}  ✓ Versión de Dropbear bloqueada para evitar actualizaciones"

    # Verificar /bin/false en shells
    [[ ! $(cat /etc/shells | grep "/bin/false") ]] && echo "/bin/false" >> /etc/shells

    # Configurar SSH estándar
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║      Configurando OpenSSH Server...        ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    cat > /etc/ssh/sshd_config << 'EOF'
# Configuración SSH optimizada por JuanitoProSniff
Port 22
Protocol 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_ecdsa_key
HostKey /etc/ssh/ssh_host_ed25519_key

# Logging
SyslogFacility AUTH
LogLevel INFO

# Autenticación
LoginGraceTime 120
PermitRootLogin yes
StrictModes yes
MaxAuthTries 6
MaxSessions 100

PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys

# Autenticación por contraseña
PasswordAuthentication yes
PermitEmptyPasswords no
ChallengeResponseAuthentication no

# Kerberos
KerberosAuthentication no

# GSSAPI
GSSAPIAuthentication no

# Configuración de seguridad
UsePAM yes
X11Forwarding yes
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
ClientAliveInterval 120
ClientAliveCountMax 3

# SFTP
Subsystem sftp /usr/lib/openssh/sftp-server

# Variables de entorno
AcceptEnv LANG LC_*
EOF

    echo -e "${cor[4]}  ✓ OpenSSH configurado"

    # Crear directorio y banner de Dropbear
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║       Configurando Dropbear Server...      ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    mkdir -p /etc/dropbear
    echo "JuanitoProSniff© - Dropbear SSH Server 2019 - Ultra Stable" > /etc/dropbear/banner
    
    # Generar llaves si no existen
    if [[ ! -f /etc/dropbear/dropbear_rsa_host_key ]]; then
        echo -e "${cor[3]}→ Generando llaves RSA..."
        dropbearkey -t rsa -f /etc/dropbear/dropbear_rsa_host_key -s 2048 &>/dev/null
        echo -e "${cor[4]}  ✓ Llave RSA generada"
    fi
    
    if [[ ! -f /etc/dropbear/dropbear_ecdsa_host_key ]]; then
        echo -e "${cor[3]}→ Generando llaves ECDSA..."
        dropbearkey -t ecdsa -f /etc/dropbear/dropbear_ecdsa_host_key &>/dev/null
        echo -e "${cor[4]}  ✓ Llave ECDSA generada"
    fi

    # Crear configuración de Dropbear
    cat > /etc/default/dropbear << EOF
# Configuración Dropbear - JuanitoProSniff
# Versión 2019 - Ultra Estable

NO_START=0
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RSAKEY="/etc/dropbear/dropbear_rsa_host_key"
DROPBEAR_RECEIVE_WINDOW=65536
DROPBEAR_EXTRA_ARGS="-w -s"
EOF

    echo -e "${cor[4]}  ✓ Archivos de configuración creados"

    # Crear servicio systemd optimizado para múltiples puertos
    echo -e "${cor[3]}→ Creando servicio systemd optimizado..."
    
    cat > /etc/systemd/system/dropbear-multi.service << EOF
[Unit]
Description=Dropbear SSH server (multiple ports) - Ultra Stable
Documentation=man:dropbear(8)
After=network.target auditd.service
ConditionPathExists=!/etc/ssh/sshd_not_to_be_run

[Service]
Type=forking
ExecStartPre=/bin/mkdir -p /var/run/dropbear
ExecStart=/usr/sbin/dropbear -F -E $(echo $PORT | sed 's/ / -p /g' | sed 's/^/-p /')
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=always
RestartSec=3
StartLimitInterval=60
StartLimitBurst=5

# Optimizaciones de recursos
Nice=-10
IOSchedulingClass=realtime
IOSchedulingPriority=0
CPUSchedulingPolicy=fifo
CPUSchedulingPriority=99

# Límites de recursos
LimitNOFILE=65536
LimitNPROC=32768

# Logging
StandardOutput=journal
StandardError=journal
SyslogIdentifier=dropbear-multi

[Install]
WantedBy=multi-user.target
EOF

    echo -e "${cor[4]}  ✓ Servicio systemd creado"

    # Optimizar configuración de red
    optimizar_red

    # Configurar firewall (UFW)
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║       Configurando Firewall (UFW)...       ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    for ufww in $PORT 22; do
        ufw allow $ufww/tcp comment "Dropbear/SSH - JuanitoProSniff" &>/dev/null
        echo -e "${cor[4]}  ✓ Puerto $ufww permitido en UFW"
    done

    # Recargar systemd e iniciar servicios
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║         Iniciando servicios...             ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    systemctl daemon-reload
    systemctl disable dropbear &>/dev/null
    systemctl enable dropbear-multi &>/dev/null
    systemctl start dropbear-multi &>/dev/null
    
    # Reiniciar SSH
    service ssh restart &>/dev/null || systemctl restart sshd &>/dev/null
    
    sleep 2
    
    # Verificar que el servicio esté activo
    if systemctl is-active --quiet dropbear-multi; then
        echo -e "${cor[4]}  ✓ Servicio dropbear-multi iniciado correctamente"
    else
        echo -e "${cor[2]}  ✗ Error iniciando servicio dropbear-multi"
        echo -e "${cor[3]}    Verificar logs: journalctl -u dropbear-multi -n 50"
    fi

    # Mostrar información final
    fun_ip
    
    echo ""
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}║      DROPBEAR CONFIGURADO EXITOSAMENTE               ║"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
    echo ""
    echo -e "${cor[0]}IP del servidor:    ${cor[4]}$IP"
    echo -e "${cor[0]}Versión Dropbear:   ${cor[4]}$dropbear_version"
    echo -e "${cor[0]}Banner:             ${cor[4]}JuanitoProSniff© - Dropbear SSH Server 2019"
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║         Puertos Configurados               ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    for puerto in $PORT; do
        if check_dropbear_port $puerto; then
            echo -e "${cor[4]}✓ Puerto $puerto ${cor[0]}(ACTIVO y ESCUCHANDO)"
        else
            echo -e "${cor[4]}✓ Puerto $puerto ${cor[3]}(CONFIGURADO)"
        fi
    done
    
    if [[ ! -z "$OCCUPIED_BY_OTHERS" ]]; then
        echo ""
        echo -e "${cor[3]}╔════════════════════════════════════════════╗"
        echo -e "${cor[3]}║    Puertos Omitidos (Ocupados)             ║"
        echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
        for puerto in $OCCUPIED_BY_OTHERS; do
            echo -e "${cor[2]}✗ Puerto $puerto ${cor[0]}(Ocupado por otro servicio)"
        done
    fi
    
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║        Características Mejoradas           ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[4]}✓${cor[0]} Dropbear versión 2019 (Ubuntu 20.04 Focal)"
    echo -e "${cor[4]}✓${cor[0]} Versión bloqueada para evitar actualizaciones"
    echo -e "${cor[4]}✓${cor[0]} Optimizaciones de kernel aplicadas"
    echo -e "${cor[4]}✓${cor[0]} TCP keepalive configurado (600s/60s/10)"
    echo -e "${cor[4]}✓${cor[0]} Buffers de red optimizados (128MB)"
    echo -e "${cor[4]}✓${cor[0]} Reinicio automático en caso de fallo"
    echo -e "${cor[4]}✓${cor[0]} Prioridad de CPU y IO optimizada"
    echo -e "${cor[4]}✓${cor[0]} Límites de recursos aumentados (65k archivos)"
    echo -e "${cor[4]}✓${cor[0]} Soporte multi-usuario (100 sesiones simultáneas)"
    echo ""
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║        Comandos de Verificación            ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[0]}Estado del servicio:     ${cor[4]}systemctl status dropbear-multi"
    echo -e "${cor[0]}Ver logs en tiempo real: ${cor[4]}journalctl -u dropbear-multi -f"
    echo -e "${cor[0]}Conexiones activas:      ${cor[4]}ss -tnp | grep dropbear"
    echo -e "${cor[0]}Verificar puertos:       ${cor[4]}ss -tlnp | grep dropbear"
    echo -e "${cor[0]}Reiniciar servicio:      ${cor[4]}systemctl restart dropbear-multi"
    echo -e "${cor[0]}Ver versión:             ${cor[4]}dropbear -V"
    echo ""
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║  Instalación completada - Sistema listo para usar    ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
}

# Ejecutar función principal
fun_dropbear