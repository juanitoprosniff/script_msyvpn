#!/bin/bash
#25/01/2021 modificado por JuanitoProSniff
#Dropbear Auto-Install - Puertos: 90, 109, 110, 143
clear
clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols"&& [[ ! -d ${SCPinst} ]] && exit
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

mportas () {
unset portas
portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
while read port; do
var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
[[ "$(echo -e $portas|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
done <<< "$portas_var"
i=1
echo -e "$portas"
}

fun_ip () {
if [[ -e /etc/VPS-AGN/MEUIPvps ]]; then
IP="$(cat /etc/VPS-AGN/MEUIPvps)"
else
MEU_IP=$(ip addr | grep 'inet' | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -o -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | head -1)
MEU_IP2=$(wget -qO- ipv4.icanhazip.com)
[[ "$MEU_IP" != "$MEU_IP2" ]] && IP="$MEU_IP2" || IP="$MEU_IP"
echo "$MEU_IP" > /etc/VPS-AGN/MEUIPvps
fi
}

fun_eth () {
eth=$(ifconfig | grep -v inet6 | grep -v lo | grep -v 127.0.0.1 | grep "encap:Ethernet" | awk '{print $1}')
    [[ $eth != "" ]] && {
    echo -e "${cor[3]} Aplicar mejoras para optimizar paquetes SSH?"
    echo -e "${cor[3]} Opción para usuarios avanzados"
    read -p " [S/N]: " -e -i n sshsn
           [[ "$sshsn" = @(s|S|y|Y) ]] && {
           echo -e "${cor[1]} Corrección de problemas de paquetes en SSH..."
           echo -e " Cual es la tasa RX"
           echo -ne "[ 1 - 999999999 ]: "; read rx
           [[ "$rx" = "" ]] && rx="999999999"
           echo -e " Cual es la tasa TX"
           echo -ne "[ 1 - 999999999 ]: "; read tx
           [[ "$tx" = "" ]] && tx="999999999"
           apt-get install ethtool -y > /dev/null 2>&1
           ethtool -G $eth rx $rx tx $tx > /dev/null 2>&1
           }
     }
}

fun_bar () {
comando="$1"
 _=$(
$comando > /dev/null 2>&1
) & > /dev/null
pid=$!
while [[ -d /proc/$pid ]]; do
echo -ne " \033[1;33m["
   for((i=0; i<20; i++)); do
   echo -ne "\033[1;31m##"
   sleep 0.1
   done
echo -ne "\033[1;33m]"
sleep 1s
echo
tput cuu1 && tput dl1
done
echo -ne " \033[1;33m[\033[1;31m########################################\033[1;33m] - \033[1;32m100%\033[0m\n"
sleep 1s
}

fun_dropbear () {
 [[ -e /etc/default/dropbear ]] && {
 echo -e "\033[1;32m REMOVIENDO DROPBEAR"
 service dropbear stop > /dev/null 2>&1
 fun_bar "apt-get remove dropbear -y"
 echo -e "\033[1;32m Dropbear Removido"
 [[ -e /etc/default/dropbear ]] && rm /etc/default/dropbear
 }

echo -e "\033[1;32m   DROPBEAR INSTALLER | BY JUANITOPROSNIFF"
echo -e "\033[1;31m Configurando puertos automáticamente: 90 109 110 143"

# Puertos predefinidos
DPORT="90 109 110 143"
TTOTAL=($DPORT)
PORT=""

    for((i=0; i<${#TTOTAL[@]}; i++)); do
        [[ $(mportas|grep "${TTOTAL[$i]}") = "" ]] && {
        echo -e "\033[1;33m Puerto elegido:\033[1;32m ${TTOTAL[$i]} OK"
        PORT="$PORT ${TTOTAL[$i]}"
        } || {
        echo -e "\033[1;33m Puerto elegido:\033[1;31m ${TTOTAL[$i]} OCUPADO"
        }
   done
   
  [[  -z $PORT ]] && {
  echo -e "\033[1;31m Ningún puerto válido fue elegido\033[0m"
  return 1
  }

sysvar=$(cat -n /etc/issue |grep 1 |cut -d' ' -f6,7,8 |sed 's/1//' |sed 's/      //' | grep -o Ubuntu)
[[ ! $(cat /etc/shells|grep "/bin/false") ]] && echo -e "/bin/false" >> /etc/shells

[[ "$sysvar" != "" ]] && {
echo -e "Port 22
Protocol 2
KeyRegenerationInterval 3600
ServerKeyBits 1024
SyslogFacility AUTH
LogLevel INFO
LoginGraceTime 120
PermitRootLogin yes
StrictModes yes
RSAAuthentication yes
PubkeyAuthentication yes
IgnoreRhosts yes
RhostsRSAAuthentication no
HostbasedAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
PasswordAuthentication yes
X11Forwarding yes
X11DisplayOffset 10
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
#UseLogin no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
UsePAM yes" > /etc/ssh/sshd_config

echo -e "${cor[2]} Instalando dropbear"
fun_bar "apt-get install dropbear -y"
apt-get install dropbear -y > /dev/null 2>&1

# Crear banner personalizado
mkdir -p /etc/dropbear
echo "JuanitoProSniff© - Dropbear SSH Server" > /etc/dropbear/banner

echo -e "${cor[2]} Configurando dropbear"

# Crear configuración con múltiples puertos
cat <<EOF > /etc/default/dropbear
NO_START=0
DROPBEAR_EXTRA_ARGS=""
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

# Configurar múltiples puertos en systemd
systemctl stop dropbear > /dev/null 2>&1

# Crear servicio personalizado para múltiples puertos
cat > /etc/systemd/system/dropbear-multi.service << EOF
[Unit]
Description=Dropbear SSH server (multiple ports)
After=network.target auditd.service
ConditionPathExists=!/etc/ssh/sshd_not_to_be_run

[Service]
Type=forking
ExecStart=/usr/sbin/dropbear -F -E $(echo $PORT | sed 's/ / -p /g' | sed 's/^/-p /')
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
StandardOutput=journal
StandardError=journal
SyslogIdentifier=dropbear

[Install]
WantedBy=multi-user.target
EOF

} || {
echo -e "Port 22
Protocol 2
KeyRegenerationInterval 3600
ServerKeyBits 1024
SyslogFacility AUTH
LogLevel INFO
LoginGraceTime 120
PermitRootLogin yes
StrictModes yes
RSAAuthentication yes
PubkeyAuthentication yes
IgnoreRhosts yes
RhostsRSAAuthentication no
HostbasedAuthentication no
PermitEmptyPasswords no
ChallengeResponseAuthentication no
PasswordAuthentication yes
X11Forwarding yes
X11DisplayOffset 10
PrintMotd no
PrintLastLog yes
TCPKeepAlive yes
#UseLogin no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
UsePAM yes" > /etc/ssh/sshd_config

echo -e "${cor[2]} Instalando dropbear"
fun_bar "apt-get install dropbear -y"

# Crear banner personalizado
mkdir -p /etc/dropbear
echo "JuanitoProSniff© - Dropbear SSH Server" > /etc/dropbear/banner

echo -e "${cor[2]} Configurando dropbear"

# Crear configuración con múltiples puertos
cat <<EOF > /etc/default/dropbear
NO_START=0
DROPBEAR_EXTRA_ARGS=""
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF

# Configurar múltiples puertos en systemd
systemctl stop dropbear > /dev/null 2>&1

# Crear servicio personalizado para múltiples puertos
cat > /etc/systemd/system/dropbear-multi.service << EOF
[Unit]
Description=Dropbear SSH server (multiple ports)
After=network.target auditd.service
ConditionPathExists=!/etc/ssh/sshd_not_to_be_run

[Service]
Type=forking
ExecStart=/usr/sbin/dropbear -F -E $(echo $PORT | sed 's/ / -p /g' | sed 's/^/-p /')
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
StandardOutput=journal
StandardError=journal
SyslogIdentifier=dropbear

[Install]
WantedBy=multi-user.target
EOF
}

# Aplicar mejoras de red automáticamente (sin preguntar)
eth=$(ifconfig | grep -v inet6 | grep -v lo | grep -v 127.0.0.1 | grep "encap:Ethernet" | awk '{print $1}')
[[ $eth != "" ]] && {
    apt-get install ethtool -y > /dev/null 2>&1
    ethtool -G $eth rx 999999999 tx 999999999 > /dev/null 2>&1 2>/dev/null
}

# Recargar systemd y iniciar servicios
systemctl daemon-reload
systemctl disable dropbear > /dev/null 2>&1
systemctl enable dropbear-multi > /dev/null 2>&1
systemctl start dropbear-multi > /dev/null 2>&1

service ssh restart > /dev/null 2>&1

echo -e "${cor[3]} Su dropbear ha sido configurado EXITOSAMENTE"

# Configurar UFW para todos los puertos
for ufww in $PORT; do
ufw allow $ufww > /dev/null 2>&1
done

# También permitir puerto 22 para SSH
ufw allow 22 > /dev/null 2>&1

# Mostrar información final
fun_ip
echo -e "${cor[4]}=================================================="
echo -e "${cor[4]} DROPBEAR CONFIGURADO EXITOSAMENTE"
echo -e "${cor[0]} IP del servidor: ${cor[4]}$IP"
echo -e "${cor[0]} Puertos configurados:"
for puerto in $PORT; do
    echo -e "${cor[4]}   ✓ Puerto $puerto"
done
echo -e "${cor[0]} Banner: JuanitoProSniff© - Dropbear SSH Server"
echo -e "${cor[3]} Para verificar: systemctl status dropbear-multi"
echo -e "${cor[4]}=================================================="
}

# Ejecutar función principal
fun_dropbear