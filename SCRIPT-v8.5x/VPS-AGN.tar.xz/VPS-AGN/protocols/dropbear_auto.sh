#!/bin/bash
# =================================================================
# SCRIPT DE INSTALACIÓN AUTOMÁTICA DE DROPBEAR
# Modificado por JuanitoProSniff para compatibilidad con Ubuntu 18-25
# - Instala automáticamente los puertos: 90, 109, 110, 143
# - Fuerza la versión de Dropbear de Ubuntu 20.04 en sistemas 22.04+
# =================================================================
#25/01/2021

clear
clear
# Definición de colores y directorios (se mantiene del original)
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols"&& [[ ! -d ${SCPinst} ]] && exit

# Función para listar puertos en uso
mportas () {
    unset portas
    portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
    while read port; do
        var1=$(echo "$port" | awk '{print $1}') && var2=$(echo "$port" | awk '{print $9}' | awk -F ":" '{print $2}')
        [[ "$(echo -e "$portas"|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
    done <<< "$portas_var"
    echo -e "$portas"
}

# Función para obtener la IP del servidor
fun_ip () {
    if [[ -e /etc/VPS-AGN/MEUIPvps ]]; then
        IP="$(cat /etc/VPS-AGN/MEUIPvps)"
    else
        MEU_IP=$(ip addr | grep 'inet' | grep -v inet6 | grep -vE '127\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | grep -o -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | head -1)
        MEU_IP2=$(wget -qO- ipv4.icanhazip.com)
        [[ "$MEU_IP" != "$MEU_IP2" ]] && IP="$MEU_IP2" || IP="$MEU_IP"
        echo "$MEU_IP" > /etc/VPS-AGN/MEUIPvps
    fi
}

# Barra de progreso
fun_bar () {
    comando="$1"
    _=$($comando > /dev/null 2>&1) & > /dev/null
    pid=$!
    while [[ -d /proc/$pid ]]; do
        echo -ne " \033[1;33m["
        for((i=0; i<20; i++)); do
            echo -ne "\033[1;31m##"
            sleep 0.1
        done
        echo -ne "\033[1;33m]"
        sleep 0.2s
        echo
        tput cuu1 && tput dl1
    done
    echo -ne " \033[1;33m[\033[1;31m########################################\033[1;33m] - \033[1;32m100%\033[0m\n"
    sleep 1s
}

# Función principal de instalación de Dropbear
fun_dropbear () {
    # Si ya existe, lo desinstala primero para asegurar una instalación limpia
    if [[ -e /etc/default/dropbear ]]; then
        echo -e "\033[1;32m REMOVIENDO INSTALACIÓN ANTERIOR DE DROPBEAR..."
        service dropbear stop > /dev/null 2>&1
        systemctl stop dropbear-multi > /dev/null 2>&1
        systemctl disable dropbear-multi > /dev/null 2>&1
        fun_bar "apt-get remove -y dropbear"
        rm -f /etc/systemd/system/dropbear-multi.service
        systemctl daemon-reload
        echo -e "\033[1;32m Dropbear anterior desinstalado."
    fi

    echo -e "\033[1;32m   INSTALADOR AUTOMÁTICO DE DROPBEAR | BY JUANITOPROSNIFF"
    echo -e "\033[1;31m Configurando puertos automáticamente: 90 109 110 143"

    # Puertos predefinidos
    DPORT="90 109 110 143"
    PORT=""
    # Valida que los puertos predefinidos no estén en uso
    for puerto in $DPORT; do
        if [[ -z "$(mportas | grep -w "$puerto")" ]]; then
            echo -e "\033[1;33m Puerto disponible:\033[1;32m $puerto ✔ OK"
            PORT="$PORT $puerto"
        else
            echo -e "\033[1;33m Puerto ocupado:\033[1;31m $puerto ✖ OCUPADO"
        fi
    done
   
    [[ -z "$PORT" ]] && {
        echo -e "\033[1;31m Ninguno de los puertos predefinidos está disponible. Abortando.\033[0m"
        return 1
    }

    # === LÓGICA DE DETECCIÓN Y FIJACIÓN DE VERSIÓN ===
    # Detecta el sistema operativo de forma moderna y fiable
    if [[ -f /etc/os-release ]]; then
        source /etc/os-release
        VERSION_ID_MAJOR=$(echo "$VERSION_ID" | cut -d. -f1)
    else
        echo -e "${cor[2]} Error: No se pudo detectar la versión de Ubuntu. Abortando."
        exit 1
    fi

    # Si es Ubuntu 22 o superior, fuerza la versión de Dropbear de Ubuntu 20.04 (focal)
    if [[ "$ID" == "ubuntu" && "$VERSION_ID_MAJOR" -ge 22 ]]; then
        echo -e "${cor[3]} Ubuntu $VERSION_ID detectado. Forzando Dropbear v2019.78 (de Ubuntu 20.04)."
        # Añade el repositorio de Focal y le da prioridad a Dropbear
        echo "deb http://archive.ubuntu.com/ubuntu/ focal main universe" > /etc/apt/sources.list.d/focal-dropbear.list
        cat <<EOF > /etc/apt/preferences.d/focal-dropbear.pref
Package: dropbear
Pin: release n=focal
Pin-Priority: 1001

Package: *
Pin: release n=focal
Pin-Priority: 100
EOF
        apt-get update > /dev/null 2>&1
    fi

    # Instalación de Dropbear
    echo -e "${cor[2]} Instalando dropbear..."
    fun_bar "apt-get install -y --allow-downgrades dropbear"

    # Limpia los archivos de configuración de APT si fueron creados
    if [[ -f /etc/apt/sources.list.d/focal-dropbear.list ]]; then
        rm /etc/apt/sources.list.d/focal-dropbear.list
        rm /etc/apt/preferences.d/focal-dropbear.pref
        apt-get update > /dev/null 2>&1
    fi

    # --- Configuración del Servicio y Banner ---
    # Crear banner personalizado
    mkdir -p /etc/dropbear
    echo "JuanitoProSniff© - Dropbear SSH Server" > /etc/dropbear/banner

    echo -e "${cor[2]} Configurando el servicio de Dropbear..."

    # Crear servicio personalizado de systemd para múltiples puertos
    # El comando sed crea una lista de argumentos "-p PUERTO1 -p PUERTO2 ..."
    PUERTOS_ARGS=$(echo $PORT | sed 's/ / -p /g' | sed 's/^/-p /')
    
    cat > /etc/systemd/system/dropbear-multi.service << EOF
[Unit]
Description=Dropbear SSH server (multiple ports by JuanitoProSniff)
After=network.target

[Service]
Type=forking
ExecStart=/usr/sbin/dropbear -E -F -b /etc/dropbear/banner ${PUERTOS_ARGS}
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOF

    # Aplicar mejoras de red automáticamente (sin preguntar)
    eth=$(ifconfig | grep -v inet6 | grep -v lo | grep -v 127.0.0.1 | grep "encap:Ethernet" | awk '{print $1}')
    if [[ -n "$eth" ]]; then
        apt-get install ethtool -y > /dev/null 2>&1
        ethtool -G "$eth" rx 999999999 tx 999999999 > /dev/null 2>&1
    fi

    # Recargar systemd y (re)iniciar los servicios
    systemctl daemon-reload
    systemctl disable --now dropbear > /dev/null 2>&1 # Deshabilita el servicio original
    systemctl enable --now dropbear-multi > /dev/null 2>&1 # Habilita e inicia el nuevo

    service ssh restart > /dev/null 2>&1

    # --- Configuración de Firewall y Mensaje Final ---
    # Configurar UFW para todos los puertos de dropbear y ssh
    for ufww in $PORT 22; do
        ufw allow "$ufww" > /dev/null 2>&1
    done

    # Mostrar información final
    fun_ip
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[4]}  DROPBEAR CONFIGURADO EXITOSAMENTE"
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[0]} IP del servidor: ${cor[4]}$IP"
    echo -e "${cor[0]} Puertos configurados:"
    for puerto in $PORT; do
        echo -e "${cor[4]}   ✓ Puerto $puerto"
    done
    echo -e "${cor[0]} Banner: JuanitoProSniff© - Dropbear SSH Server"
    echo -e "${cor[3]} Para verificar, usa: ${cor[1]}systemctl status dropbear-multi"
    echo -e "${cor[4]}=================================================="
}

# Ejecutar función principal
fun_dropbear
