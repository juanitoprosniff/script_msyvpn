#!/bin/bash
#25/01/2021 modificado por JuanitoProSniff
#Mejorado para Ubuntu Server 18, 20, 22, 24, 25
clear
clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols"&& [[ ! -d ${SCPinst} ]] && exit
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Instalar dependencias necesarias
[[ $(dpkg --get-selections|grep -w "python3"|head -1) ]] || {
    echo -e "${cor[3]}Instalando Python3..."
    apt-get update -y &>/dev/null
    apt-get install python3 python3-pip -y &>/dev/null
}
[[ $(dpkg --get-selections|grep -w "python"|head -1) ]] || apt-get install python -y &>/dev/null
[[ $(dpkg --get-selections|grep -w "screen"|head -1) ]] || apt-get install screen -y &>/dev/null
[[ $(dpkg --get-selections|grep -w "lsof"|head -1) ]] || apt-get install lsof -y &>/dev/null

mportas () {
    unset portas
    # Mejorado para detectar puertos correctamente
    portas_var=$(netstat -tlnp 2>/dev/null | grep LISTEN | grep -v ":::" || ss -tlnp | grep LISTEN | grep -v ":::")
    while read port; do
        if [[ ! -z "$port" ]]; then
            var1=$(echo $port | awk '{print $1}' | cut -d: -f1)
            var2=$(echo $port | awk '{print $4}' | cut -d: -f2)
            [[ "$(echo -e $portas|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
        fi
    done <<< "$portas_var"
    echo -e "$portas"
}

meu_ip () {
    # Mejorado para obtener IP correctamente
    MEU_IP=$(hostname -I | awk '{print $1}' 2>/dev/null)
    [[ -z "$MEU_IP" ]] && MEU_IP=$(ip route get 8.8.8.8 | awk 'NR==1 {print $7}' 2>/dev/null)
    MEU_IP2=$(curl -s -4 ifconfig.me 2>/dev/null || wget -qO- ipv4.icanhazip.com 2>/dev/null)
    [[ "$MEU_IP" != "$MEU_IP2" ]] && echo "$MEU_IP2" || echo "$MEU_IP"
}

tcpbypass_fun () {
    [[ -e $HOME/socks ]] && rm -rf $HOME/socks > /dev/null 2>&1
    [[ -d $HOME/socks ]] && rm -rf $HOME/socks > /dev/null 2>&1
    cd $HOME && mkdir socks > /dev/null 2>&1
    cd socks
    
    # Actualizado para usar repositorio funcional
    patch="https://raw.githubusercontent.com/JuanitoProSniff/VPS-Tools/master/LINKS-LIBRARIES/backsocz.zip"
    arq="backsocz.zip"
    
    echo -e "${cor[3]}Descargando componentes TCP Bypass..."
    wget $patch > /dev/null 2>&1 || {
        echo -e "${cor[2]}Error al descargar componentes TCP Bypass"
        return 1
    }
    
    unzip $arq > /dev/null 2>&1
    
    # Verificar y aplicar configuración SSH
    if [[ -f /root/socks/backsocz/ssh ]]; then
        cp /etc/ssh/sshd_config /etc/ssh/sshd_config.backup.$(date +%s)
        mv -f /root/socks/backsocz/ssh /etc/ssh/sshd_config
        systemctl restart sshd || service ssh restart
    fi
    
    # Instalar componentes con verificación de Python
    PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null || echo "3.8")
    
    if [[ -f /root/socks/backsocz/sckt${PYTHON_VERSION} ]]; then
        mv -f /root/socks/backsocz/sckt${PYTHON_VERSION} /usr/sbin/sckt
    elif [[ -f /root/socks/backsocz/sckt ]]; then
        mv -f /root/socks/backsocz/sckt /usr/sbin/sckt
    fi
    
    [[ -f /root/socks/backsocz/scktcheck ]] && {
        mv -f /root/socks/backsocz/scktcheck /bin/scktcheck
        chmod +x /bin/scktcheck
    }
    
    chmod +x /usr/sbin/sckt 2>/dev/null
    
    rm -rf $HOME/socks
    cd $HOME
    
    msg="$2"
    [[ $msg = "" ]] && msg="JuanitoProSniff"
    portxz="$1"
    [[ $portxz = "" ]] && portxz="8080"
    
    # Verificar que los archivos fueron instalados
    if [[ -x /bin/scktcheck && -x /usr/sbin/sckt ]]; then
        screen -dmS sokz scktcheck "$portxz" "$msg" > /dev/null 2>&1
        echo -e "${cor[4]}TCP Bypass iniciado en puerto $portxz"
    else
        echo -e "${cor[2]}Error: No se pudieron instalar los componentes TCP Bypass"
        return 1
    fi
}

gettunel_fun () {
    echo "master=NetVPS" > ${SCPinst}/pwd.pwd
    while read service; do
        [[ -z $service ]] && break
        echo "127.0.0.1:$(echo $service|cut -d' ' -f2)=$(echo $service|cut -d' ' -f1)" >> ${SCPinst}/pwd.pwd
    done <<< "$(mportas)"
    
    if [[ -f ${SCPinst}/PGet.py ]]; then
        screen -dmS getpy python3 ${SCPinst}/PGet.py -b "0.0.0.0:$1" -p "${SCPinst}/pwd.pwd" 2>/dev/null || \
        screen -dmS getpy python ${SCPinst}/PGet.py -b "0.0.0.0:$1" -p "${SCPinst}/pwd.pwd"
        
        sleep 2
        if [[ "$(ps ax | grep "PGet.py" | grep -v "grep")" ]]; then
            echo -e "${cor[4]}Gettunel iniciado exitosamente"
            msg -bar
            echo -ne "${cor[3]}Tu contraseña de Gettunel es: "
            echo -e "${cor[4]}JuanitoProSniff"
            msg -bar
        else
            echo -e "${cor[2]}Gettunel no se pudo iniciar"
        fi
    else
        echo -e "${cor[2]}Archivo PGet.py no encontrado"
    fi
    msg -bar
}

PythonDic_fun () {
    echo -e "${cor[3]}  Selecciona Puerto Local y Cabecera${cor[0]}" 
    msg -bar
    echo -ne "${cor[0]}Ingresa un puerto SSH/DROPBEAR activo: ${cor[4]}" && read puetoantla 
    msg -bar
    echo -ne "${cor[0]}Respuesta de cabecera (200,101,404,500,etc): ${cor[4]}" && read rescabeza
    msg -bar
    
    # Crear directorio si no existe
    mkdir -p /etc/VPS-AGN/protocols/
    
    cat > /etc/VPS-AGN/protocols/PDirect.py << 'PYTHON'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket, threading, select, signal, sys, time, getopt
from _thread import start_new_thread

# Configuración
LISTENING_ADDR = '0.0.0.0'
if len(sys.argv) > 1:
    LISTENING_PORT = int(sys.argv[1])
else:
    LISTENING_PORT = 80

PASS = ''
BUFLEN = 4096 * 4
TIMEOUT = 60
DEFAULT_HOST = '127.0.0.1:PUERTO_SSH_PLACEHOLDER'
RESPONSE = 'HTTP/1.1 RESPUESTA_PLACEHOLDER JuanitoProSniff\r\nContent-length: 0\r\n\r\nHTTP/1.1 RESPUESTA_PLACEHOLDER Connection established\r\n\r\n'

class Server:
    def __init__(self, host, port):
        self.running = False
        self.host = host
        self.port = port
        self.threads = []
        self.server_socket = None

    def start_server(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            
            print(f"\n:-------Proxy Python Directo-------:")
            print(f"Escuchando en: {self.host}:{self.port}")
            print(f"Puerto SSH/Dropbear: {DEFAULT_HOST}")
            print(f":----------------------------------:\n")
            
            while self.running:
                try:
                    client_socket, addr = self.server_socket.accept()
                    client_socket.settimeout(60)
                    start_new_thread(self.handle_client, (client_socket, addr))
                except Exception as e:
                    if self.running:
                        print(f"Error aceptando conexión: {e}")
                        
        except Exception as e:
            print(f"Error iniciando servidor: {e}")
        finally:
            self.stop_server()

    def handle_client(self, client_socket, addr):
        try:
            request = client_socket.recv(BUFLEN).decode('utf-8', errors='ignore')
            
            # Buscar host en headers
            host_port = self.find_header(request, 'X-Real-Host')
            if not host_port:
                host_port = DEFAULT_HOST
                
            # Verificar contraseña si es necesaria
            if PASS:
                passwd = self.find_header(request, 'X-Pass')
                if passwd != PASS:
                    client_socket.send(b'HTTP/1.1 400 Wrong Password!\r\n\r\n')
                    return
                    
            # Conectar al destino
            if host_port.startswith('127.0.0.1') or host_port.startswith('localhost'):
                self.method_connect(client_socket, host_port)
            else:
                client_socket.send(b'HTTP/1.1 403 Forbidden!\r\n\r\n')
                
        except Exception as e:
            print(f"Error manejando cliente {addr}: {e}")
        finally:
            try:
                client_socket.close()
            except:
                pass

    def find_header(self, request, header):
        lines = request.split('\r\n')
        for line in lines:
            if line.startswith(header + ':'):
                return line.split(':', 1)[1].strip()
        return ''

    def method_connect(self, client_socket, host_port):
        try:
            # Parsear host y puerto
            if ':' in host_port:
                host, port = host_port.split(':')
                port = int(port)
            else:
                host = host_port
                port = 22  # Puerto por defecto
                
            # Conectar al destino
            target_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            target_socket.connect((host, port))
            
            # Enviar respuesta de éxito
            client_socket.send(RESPONSE.encode())
            
            # Relay de datos
            self.relay_data(client_socket, target_socket)
            
        except Exception as e:
            print(f"Error en conexión: {e}")
            try:
                client_socket.send(b'HTTP/1.1 500 Connection Failed\r\n\r\n')
            except:
                pass

    def relay_data(self, client_socket, target_socket):
        try:
            while True:
                ready, _, _ = select.select([client_socket, target_socket], [], [], 3)
                if not ready:
                    break
                    
                for sock in ready:
                    try:
                        data = sock.recv(BUFLEN)
                        if not data:
                            return
                            
                        if sock is client_socket:
                            target_socket.send(data)
                        else:
                            client_socket.send(data)
                    except:
                        return
        except:
            pass
        finally:
            try:
                target_socket.close()
            except:
                pass

    def stop_server(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass

def signal_handler(sig, frame):
    print('\nDeteniendo servidor...')
    sys.exit(0)

if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)
    
    if len(sys.argv) < 3:
        print("Uso: python3 PDirect.py <puerto> <texto_banner>")
        sys.exit(1)
        
    port = int(sys.argv[1])
    banner = sys.argv[2] if len(sys.argv) > 2 else "JuanitoProSniff"
    
    server = Server('0.0.0.0', port)
    server.start_server()
PYTHON

    # Reemplazar placeholders
    sed -i "s/PUERTO_SSH_PLACEHOLDER/$puetoantla/g" /etc/VPS-AGN/protocols/PDirect.py
    sed -i "s/RESPUESTA_PLACEHOLDER/$rescabeza/g" /etc/VPS-AGN/protocols/PDirect.py
    
    chmod +x /etc/VPS-AGN/protocols/PDirect.py
    
    # Iniciar el proxy
    screen -dmS pydic-"$porta_socket" python3 /etc/VPS-AGN/protocols/PDirect.py "$porta_socket" "$texto_soket"
    
    # Verificar que se inició
    sleep 2
    if pgrep -f "PDirect.py.*$porta_socket" > /dev/null; then
        echo -e "${cor[4]}Proxy Python Directo iniciado en puerto $porta_socket"
        echo "$porta_socket $texto_soket" >> /etc/VPS-AGN/PortPD.log
    else
        echo -e "${cor[2]}Error: No se pudo iniciar el Proxy Python Directo"
    fi
}

pid_kill () {
    [[ -z $1 ]] && return 1
    pids="$@"
    for pid in $(echo $pids); do
        kill -9 $pid &>/dev/null 2>&1
    done
}

remove_fun () {
    echo -e "${cor[3]}Deteniendo Socks Python"
    msg -bar
    
    # Lista de procesos a detener
    for proceso in "PPub.py" "PPriv.py" "PDirect.py" "POpen.py" "PGet.py" "scktcheck" "python.py"; do
        pidproxy=$(pgrep -f "$proceso" | head -10)
        [[ ! -z $pidproxy ]] && {
            echo -e "${cor[3]}Deteniendo $proceso..."
            kill -9 $pidproxy &>/dev/null
        }
    done
    
    # Detener screens
    screen -ls | grep -E "(sokz|getpy|pydic|screen)" | cut -d. -f1 | awk '{print $1}' | xargs -I {} screen -X -S {} quit 2>/dev/null
    
    echo -e "${cor[2]}  Todos los Socks DETENIDOS"
    msg -bar
    
    # Limpiar logs
    rm -rf /etc/VPS-AGN/PortPD.log 2>/dev/null
    echo "" > /etc/VPS-AGN/PortPD.log 2>/dev/null
    exit 0
}

iniciarsocks () {
    # Verificar estados de servicios
    pidproxy=$(pgrep -f "PPub.py") && P1="${cor[4]}[ACTIVO]" || P1="${cor[2]}[INACTIVO]"
    pidproxy2=$(pgrep -f "PPriv.py") && P2="${cor[4]}[ACTIVO]" || P2="${cor[2]}[INACTIVO]"
    pidproxy3=$(pgrep -f "PDirect.py") && P3="${cor[4]}[ACTIVO]" || P3="${cor[2]}[INACTIVO]"
    pidproxy4=$(pgrep -f "POpen.py") && P4="${cor[4]}[ACTIVO]" || P4="${cor[2]}[INACTIVO]"
    pidproxy5=$(pgrep -f "PGet.py") && P5="${cor[4]}[ACTIVO]" || P5="${cor[2]}[INACTIVO]"
    pidproxy6=$(pgrep -f "scktcheck") && P6="${cor[4]}[ACTIVO]" || P6="${cor[2]}[INACTIVO]"
    
    msg -bar 
    msg -tit
    echo -e "${cor[3]}   INSTALADOR DE PROXY'S VPS-AGN Por JuanitoProSniff"
    msg -bar
    echo -e "${cor[4]} [1] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python SIMPLE${cor[0]} ---- $P1"
    echo -e "${cor[4]} [2] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python SEGURO${cor[0]} ---- $P2"
    echo -e "${cor[4]} [3] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python DIRECTO${cor[0]} ---- $P3"
    echo -e "${cor[4]} [4] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python OPENVPN${cor[0]} ---- $P4"
    echo -e "${cor[4]} [5] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python GETTUNEL${cor[0]} ---- $P5"
    echo -e "${cor[4]} [6] $(echo -e '\033[1;32m==>>') ${cor[0]}Proxy Python TCP BYPASS${cor[0]} ---- $P6"
    echo -e "${cor[4]} [7] $(echo -e '\033[1;32m==>>') ${cor[0]} ¡¡ DETENER TODOS LOS PROXY'S !!"
    echo -e "$(msg -bar)\n${cor[4]} [0] $(echo -e '\033[1;32m==>>') \033[1;97m\033[1;41m VOLVER \033[1;37m"
    msg -bar
    
    IP=$(meu_ip)
    
    while [[ -z $portproxy || ! $portproxy =~ ^[0-7]$ ]]; do
        echo -ne "${cor[3]}Selecciona una opción: ${cor[0]}" && read portproxy
        tput cuu1 && tput dl1
    done
    
    case $portproxy in
        7) remove_fun ;;
        0) return ;;
    esac
    
    echo -e "${cor[3]}       Selecciona Puerto Principal del Proxy"
    msg -bar
    
    porta_socket=""
    while [[ -z $porta_socket ]]; do
        echo -ne "Ingresa el puerto: ${cor[4]}" && read porta_socket
        
        # Verificar que el puerto sea válido
        if [[ ! $porta_socket =~ ^[0-9]+$ ]] || [[ $porta_socket -lt 1 ]] || [[ $porta_socket -gt 65535 ]]; then
            echo -e "${cor[2]}Puerto inválido. Usa un número entre 1-65535"
            porta_socket=""
            continue
        fi
        
        # Verificar si el puerto ya está en uso
        if netstat -tlnp 2>/dev/null | grep -q ":$porta_socket " || ss -tlnp 2>/dev/null | grep -q ":$porta_socket "; then
            echo -e "${cor[2]}Puerto $porta_socket ya está en uso. Selecciona otro."
            porta_socket=""
            continue
        fi
        
        tput cuu1 && tput dl1
    done
    
    echo -e "${cor[3]}Ingresa tu Mini-Banner"
    msg -bar
    echo -ne "Ingresa el texto de estado (texto plano o HTML):\n ${cor[0]}" && read texto_soket
    msg -bar
    
    case $portproxy in
        1) 
            if [[ -f ${SCPinst}/PPub.py ]]; then
                screen -dmS pysimp-"$porta_socket" python3 ${SCPinst}/PPub.py "$porta_socket" "$texto_soket" 2>/dev/null || \
                screen -dmS pysimp-"$porta_socket" python ${SCPinst}/PPub.py "$porta_socket" "$texto_soket"
                echo -e "${cor[4]}Proxy Simple iniciado en puerto $porta_socket"
            else
                echo -e "${cor[2]}Archivo PPub.py no encontrado"
            fi
            ;;
        2) 
            if [[ -f ${SCPinst}/PPriv.py ]]; then
                screen -dmS pysec-"$porta_socket" python3 ${SCPinst}/PPriv.py "$porta_socket" "$texto_soket" "$IP" 2>/dev/null || \
                screen -dmS pysec-"$porta_socket" python ${SCPinst}/PPriv.py "$porta_socket" "$texto_soket" "$IP"
                echo -e "${cor[4]}Proxy Seguro iniciado en puerto $porta_socket"
            else
                echo -e "${cor[2]}Archivo PPriv.py no encontrado"
            fi
            ;;
        3) PythonDic_fun ;;
        4) 
            if [[ -f ${SCPinst}/POpen.py ]]; then
                screen -dmS pyopen-"$porta_socket" python3 ${SCPinst}/POpen.py "$porta_socket" "$texto_soket" 2>/dev/null || \
                screen -dmS pyopen-"$porta_socket" python ${SCPinst}/POpen.py "$porta_socket" "$texto_soket"
                echo -e "${cor[4]}Proxy OpenVPN iniciado en puerto $porta_socket"
            else
                echo -e "${cor[2]}Archivo POpen.py no encontrado"
            fi
            ;;
        5) gettunel_fun "$porta_socket" ;;
        6) tcpbypass_fun "$porta_socket" "$texto_soket" ;;
    esac
    
    echo -e "${cor[4]}Procedimiento COMPLETADO"
    msg -bar
    
    # Verificar si el servicio se inició correctamente
    sleep 3
    case $portproxy in
        1) proceso="PPub.py" ;;
        2) proceso="PPriv.py" ;;
        3) proceso="PDirect.py" ;;
        4) proceso="POpen.py" ;;
        5) proceso="PGet.py" ;;
        6) proceso="scktcheck" ;;
    esac
    
    if [[ $portproxy -ne 5 && $portproxy -ne 6 ]]; then
        if pgrep -f "$proceso.*$porta_socket" > /dev/null; then
            echo -e "${cor[4]}✓ Servicio iniciado correctamente y escuchando en puerto $porta_socket"
        else
            echo -e "${cor[2]}✗ Advertencia: El servicio puede no haberse iniciado correctamente"
            echo -e "${cor[3]}Verifica los logs con: screen -r py*-$porta_socket"
        fi
    fi
    
    msg -bar
}

iniciarsocks