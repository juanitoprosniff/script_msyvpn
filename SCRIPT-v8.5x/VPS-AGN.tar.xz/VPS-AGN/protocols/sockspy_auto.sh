#!/bin/bash
#25/01/2021 modificado por JuanitoProSniff
#Mejorado para Ubuntu Server 18, 20, 22, 24, 25
#Versión Direct Proxy Only - Auto Configuración - MULTI-RESPONSE
clear
clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols"&& [[ ! -d ${SCPinst} ]] && exit
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Instalar dependencias necesarias
[[ $(dpkg --get-selections|grep -w "python3"|head -1) ]] || {
    echo -e "${cor[3]}Instalando Python3..."
    apt-get update -y &>/dev/null
    apt-get install python3 python3-pip -y &>/dev/null
}
[[ $(dpkg --get-selections|grep -w "python"|head -1) ]] || apt-get install python -y &>/dev/null
[[ $(dpkg --get-selections|grep -w "screen"|head -1) ]] || apt-get install screen -y &>/dev/null
[[ $(dpkg --get-selections|grep -w "lsof"|head -1) ]] || apt-get install lsof -y &>/dev/null

meu_ip () {
    # Mejorado para obtener IP correctamente
    MEU_IP=$(hostname -I | awk '{print $1}' 2>/dev/null)
    [[ -z "$MEU_IP" ]] && MEU_IP=$(ip route get 8.8.8.8 | awk 'NR==1 {print $7}' 2>/dev/null)
    MEU_IP2=$(curl -s -4 ifconfig.me 2>/dev/null || wget -qO- ipv4.icanhazip.com 2>/dev/null)
    [[ "$MEU_IP" != "$MEU_IP2" ]] && echo "$MEU_IP2" || echo "$MEU_IP"
}

create_python_proxy() {
    local puerto=$1
    local puerto_ssh=$2
    local respuesta_principal=$3
    local mensaje_html="JuanitoProSniff©"
    
    # Crear directorio si no existe
    mkdir -p /etc/VPS-AGN/protocols/
    
    cat > /etc/VPS-AGN/protocols/PDirect_${puerto}.py << PYTHON
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import socket, threading, select, signal, sys, time
from _thread import start_new_thread

# Configuración
LISTENING_ADDR = '0.0.0.0'
LISTENING_PORT = ${puerto}
PASS = ''
BUFLEN = 4096 * 4
TIMEOUT = 60
DEFAULT_HOST = '127.0.0.1:${puerto_ssh}'
MENSAJE_HTML = '${mensaje_html}'

# Múltiples respuestas disponibles con mensaje HTML
RESPONSES = {
    '101': f'HTTP/1.1 101 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 101 Connection established\\r\\n\\r\\n',
    '200': f'HTTP/1.1 200 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 200 Connection established\\r\\n\\r\\n',
    '201': f'HTTP/1.1 201 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 201 Connection established\\r\\n\\r\\n',
    '202': f'HTTP/1.1 202 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 202 Connection established\\r\\n\\r\\n',
    '300': f'HTTP/1.1 300 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 300 Connection established\\r\\n\\r\\n',
    '301': f'HTTP/1.1 301 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 301 Connection established\\r\\n\\r\\n',
    '302': f'HTTP/1.1 302 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 302 Connection established\\r\\n\\r\\n',
    '400': f'HTTP/1.1 400 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 400 Connection established\\r\\n\\r\\n',
    '401': f'HTTP/1.1 401 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 401 Connection established\\r\\n\\r\\n',
    '403': f'HTTP/1.1 403 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 403 Connection established\\r\\n\\r\\n',
    '404': f'HTTP/1.1 404 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 404 Connection established\\r\\n\\r\\n',
    '500': f'HTTP/1.1 500 {MENSAJE_HTML}\\r\\nContent-length: 0\\r\\n\\r\\nHTTP/1.1 500 Connection established\\r\\n\\r\\n',
}

# Respuesta principal para este puerto
RESPONSE_PRINCIPAL = '${respuesta_principal}'

class Server:
    def __init__(self, host, port):
        self.running = False
        self.host = host
        self.port = port
        self.threads = []
        self.server_socket = None

    def start_server(self):
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.running = True
            
            print(f"Proxy Python Directo iniciado en puerto {self.port} -> SSH:{DEFAULT_HOST}")
            print(f"Respuesta principal: {RESPONSE_PRINCIPAL} - Múltiples respuestas disponibles")
            
            while self.running:
                try:
                    client_socket, addr = self.server_socket.accept()
                    client_socket.settimeout(60)
                    start_new_thread(self.handle_client, (client_socket, addr))
                except Exception as e:
                    if self.running:
                        print(f"Error aceptando conexión: {e}")
                        
        except Exception as e:
            print(f"Error iniciando servidor en puerto {self.port}: {e}")
        finally:
            self.stop_server()

    def handle_client(self, client_socket, addr):
        try:
            request = client_socket.recv(BUFLEN).decode('utf-8', errors='ignore')
            
            # Buscar host en headers
            host_port = self.find_header(request, 'X-Real-Host')
            if not host_port:
                host_port = DEFAULT_HOST
                
            # Verificar contraseña si es necesaria
            if PASS:
                passwd = self.find_header(request, 'X-Pass')
                if passwd != PASS:
                    client_socket.send(f'HTTP/1.1 400 {MENSAJE_HTML}\\r\\n\\r\\n'.encode())
                    return
            
            # Buscar respuesta personalizada en headers
            custom_response = self.find_header(request, 'X-Response')
            if custom_response and custom_response in RESPONSES:
                response_code = custom_response
            else:
                response_code = RESPONSE_PRINCIPAL
                    
            # Conectar al destino
            if host_port.startswith('127.0.0.1') or host_port.startswith('localhost'):
                self.method_connect(client_socket, host_port, response_code)
            else:
                client_socket.send(f'HTTP/1.1 403 {MENSAJE_HTML}\\r\\n\\r\\n'.encode())
                
        except Exception as e:
            pass
        finally:
            try:
                client_socket.close()
            except:
                pass

    def find_header(self, request, header):
        lines = request.split('\\r\\n')
        for line in lines:
            if line.startswith(header + ':'):
                return line.split(':', 1)[1].strip()
        return ''

    def method_connect(self, client_socket, host_port, response_code):
        try:
            # Parsear host y puerto
            if ':' in host_port:
                host, port = host_port.split(':')
                port = int(port)
            else:
                host = host_port
                port = 22  # Puerto por defecto
                
            # Conectar al destino
            target_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            target_socket.connect((host, port))
            
            # Enviar respuesta personalizada
            if response_code in RESPONSES:
                response = RESPONSES[response_code]
            else:
                response = RESPONSES[RESPONSE_PRINCIPAL]
                
            client_socket.send(response.encode())
            
            # Relay de datos
            self.relay_data(client_socket, target_socket)
            
        except Exception as e:
            try:
                client_socket.send(f'HTTP/1.1 500 {MENSAJE_HTML}\\r\\n\\r\\n'.encode())
            except:
                pass

    def relay_data(self, client_socket, target_socket):
        try:
            while True:
                ready, _, _ = select.select([client_socket, target_socket], [], [], 3)
                if not ready:
                    break
                    
                for sock in ready:
                    try:
                        data = sock.recv(BUFLEN)
                        if not data:
                            return
                            
                        if sock is client_socket:
                            target_socket.send(data)
                        else:
                            client_socket.send(data)
                    except:
                        return
        except:
            pass
        finally:
            try:
                target_socket.close()
            except:
                pass

    def stop_server(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass

def signal_handler(sig, frame):
    sys.exit(0)

if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)
    
    server = Server('0.0.0.0', LISTENING_PORT)
    server.start_server()
PYTHON

    chmod +x /etc/VPS-AGN/protocols/PDirect_${puerto}.py
}

check_port_available() {
    local port=$1
    if netstat -tlnp 2>/dev/null | grep -q ":$port " || ss -tlnp 2>/dev/null | grep -q ":$port "; then
        return 1  # Puerto ocupado
    else
        return 0  # Puerto disponible
    fi
}

check_ssh_port() {
    # Verificar si puerto 90 está activo
    if netstat -tlnp 2>/dev/null | grep -q ":90 " || ss -tlnp 2>/dev/null | grep -q ":90 "; then
        echo "90"
    else
        echo "22"
    fi
}

main() {
    echo -e "${cor[3]}   PROXY DIRECTO MULTI-RESPONSE Por JuanitoProSniff"
    echo -e "${cor[4]}====================================================="
    echo -e "${cor[0]}Configurando proxies con múltiples respuestas..."
    echo ""
    
    # Puertos a configurar con sus respuestas principales
    declare -A PUERTOS_CONFIG=(
        [80]="101"
        [8080]="101"
        [8088]="101"
        [8280]="101"
        [8880]="101"
        [2052]="200"
        [2082]="200"
        [2086]="200"
        [2095]="200"
    )
    
    # Verificar puerto SSH a usar
    PUERTO_SSH=$(check_ssh_port)
    echo -e "${cor[3]}Puerto SSH/Dropbear detectado: ${cor[4]}$PUERTO_SSH"
    
    # Detener procesos previos
    echo -e "${cor[3]}Deteniendo procesos previos..."
    pkill -f "PDirect_" 2>/dev/null
    screen -ls | grep -E "pydirect-" | cut -d. -f1 | awk '{print $1}' | xargs -I {} screen -X -S {} quit 2>/dev/null
    
    # Configurar cada puerto
    for puerto in "${!PUERTOS_CONFIG[@]}"; do
        respuesta_principal="${PUERTOS_CONFIG[$puerto]}"
        
        if check_port_available $puerto; then
            echo -e "${cor[3]}Configurando puerto ${cor[4]}$puerto${cor[3]} con respuesta principal ${cor[4]}$respuesta_principal"
            
            # Crear archivo Python para este puerto
            create_python_proxy $puerto $PUERTO_SSH $respuesta_principal
            
            # Iniciar el proxy en screen
            screen -dmS pydirect-$puerto python3 /etc/VPS-AGN/protocols/PDirect_${puerto}.py
            
            # Verificar que se inició
            sleep 1
            if pgrep -f "PDirect_${puerto}.py" > /dev/null; then
                echo -e "${cor[4]}✓ Proxy iniciado en puerto $puerto (Principal: $respuesta_principal)"
            else
                echo -e "${cor[2]}✗ Error iniciando proxy en puerto $puerto"
            fi
        else
            echo -e "${cor[2]}✗ Puerto $puerto ya está en uso, omitiendo..."
        fi
    done
    
    echo ""
    echo -e "${cor[4]}====================================================="
    echo -e "${cor[4]}CONFIGURACIÓN MULTI-RESPONSE COMPLETADA"
    echo -e "${cor[0]}Puerto SSH utilizado: ${cor[4]}$PUERTO_SSH"
    echo -e "${cor[0]}Mensaje HTML en todas las respuestas: ${cor[4]}JuanitoProSniff©"
    echo -e "${cor[4]}====================================================="
    
    echo ""
    echo -e "${cor[3]}RESPUESTAS CONFIGURADAS POR PUERTO:"
    echo -e "${cor[4]}Puertos 80, 8080, 8088, 8280, 8880: ${cor[0]}Respuesta principal 101"
    echo -e "${cor[4]}Puertos 2052, 2082, 2086, 2095: ${cor[0]}Respuesta principal 200"
    
    # Mostrar resumen de puertos activos
    echo ""
    echo -e "${cor[3]}RESUMEN DE PUERTOS ACTIVOS:"
    active_count=0
    for puerto in "${!PUERTOS_CONFIG[@]}"; do
        if pgrep -f "PDirect_${puerto}.py" > /dev/null; then
            respuesta_principal="${PUERTOS_CONFIG[$puerto]}"
            echo -e "${cor[4]}✓ Puerto $puerto - Principal: $respuesta_principal - SSH: $PUERTO_SSH"
            ((active_count++))
        fi
    done
    
    echo ""
    echo -e "${cor[4]}Total de proxies activos: $active_count/${#PUERTOS_CONFIG[@]}"
    echo ""
    echo -e "${cor[3]}FUNCIONALIDADES MEJORADAS:"
    echo -e "${cor[0]}• Cada puerto puede responder con múltiples códigos (101, 200, 201, 202, 300, 301, 302, 400, 401, 403, 404, 500)"
    echo -e "${cor[0]}• Mensaje 'JuanitoProSniff©' incluido en TODAS las respuestas"
    echo -e "${cor[0]}• Para usar respuesta personalizada, agregar header: X-Response: CODIGO"
    echo -e "${cor[0]}• Ejemplo: X-Response: 404 para respuesta 404 con mensaje HTML"
    echo ""
    echo -e "${cor[3]}Para monitorear los proxies use: ${cor[0]}screen -ls"
    echo -e "${cor[3]}Para acceder a un proxy: ${cor[0]}screen -r pydirect-PUERTO"
}

# Ejecutar función principal
main