#!/bin/bash
#====================================================================
# SOCKSPY AUTO - VERSIÓN MEJORADA Y OPTIMIZADA
# Modificado por JuanitoProSniff
# Mejorado para Ubuntu Server 20, 22, 23, 24
# Versión Direct Proxy Multi-Response con ALTA ESTABILIDAD
# Fecha: 2026 - Optimizado para múltiples usuarios concurrentes
#====================================================================

clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols" && [[ ! -d ${SCPinst} ]] && exit

declare -A cor=( 
    [0]="\033[1;37m" 
    [1]="\033[1;34m" 
    [2]="\033[1;31m" 
    [3]="\033[1;33m" 
    [4]="\033[1;32m" 
)

#====================================================================
# INSTALACIÓN DE DEPENDENCIAS CON VERIFICACIÓN MEJORADA
#====================================================================
instalar_dependencias() {
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║  Verificando e instalando dependencias... ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    # Python3 y pip
    if ! dpkg -l | grep -qw python3; then
        echo -e "${cor[3]}→ Instalando Python3..."
        apt-get update -qq &>/dev/null
        apt-get install -y python3 python3-pip &>/dev/null
        echo -e "${cor[4]}  ✓ Python3 instalado"
    fi
    
    # Python2 (para compatibilidad)
    if ! dpkg -l | grep -qw python; then
        apt-get install -y python &>/dev/null
    fi
    
    # Screen
    if ! dpkg -l | grep -qw screen; then
        echo -e "${cor[3]}→ Instalando Screen..."
        apt-get install -y screen &>/dev/null
        echo -e "${cor[4]}  ✓ Screen instalado"
    fi
    
    # lsof
    if ! dpkg -l | grep -qw lsof; then
        echo -e "${cor[3]}→ Instalando lsof..."
        apt-get install -y lsof &>/dev/null
        echo -e "${cor[4]}  ✓ lsof instalado"
    fi
    
    # net-tools (para mejor compatibilidad)
    if ! dpkg -l | grep -qw net-tools; then
        apt-get install -y net-tools &>/dev/null
    fi
    
    echo -e "${cor[4]}✓ Todas las dependencias instaladas correctamente\n"
}

#====================================================================
# OBTENER IP DEL SERVIDOR
#====================================================================
meu_ip() {
    # Intentar múltiples métodos para obtener la IP
    local MEU_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    
    if [[ -z "$MEU_IP" ]]; then
        MEU_IP=$(ip route get 8.8.8.8 2>/dev/null | awk 'NR==1 {print $7}')
    fi
    
    if [[ -z "$MEU_IP" ]]; then
        MEU_IP=$(ip addr show | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d/ -f1 | head -1)
    fi
    
    local MEU_IP2=$(curl -s -4 --connect-timeout 3 ifconfig.me 2>/dev/null || wget -qO- --timeout=3 ipv4.icanhazip.com 2>/dev/null)
    
    [[ -n "$MEU_IP2" ]] && echo "$MEU_IP2" || echo "$MEU_IP"
}

#====================================================================
# CREAR SCRIPT PYTHON MEJORADO CON ALTA ESTABILIDAD
#====================================================================
create_python_proxy() {
    local puerto=$1
    local puerto_ssh=$2
    local respuesta_principal=$3
    local mensaje_html="JuanitoProSniff©"
    
    mkdir -p /etc/VPS-AGN/protocols/
    
    cat > /etc/VPS-AGN/protocols/PDirect_${puerto}.py << 'PYTHON_SCRIPT'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Proxy Directo Multi-Response - Versión Optimizada
Alta estabilidad para múltiples usuarios concurrentes
Configuración: Puerto PORT_PLACEHOLDER -> SSH:SSH_PORT_PLACEHOLDER
"""

import socket
import threading
import select
import signal
import sys
import time
import logging
from datetime import datetime

# ═══════════════════════════════════════════════════════════════
# CONFIGURACIÓN PRINCIPAL
# ═══════════════════════════════════════════════════════════════
LISTENING_ADDR = '0.0.0.0'
LISTENING_PORT = PORT_PLACEHOLDER
PASS = ''
BUFLEN = 8192  # Aumentado para mejor rendimiento
TIMEOUT = 90   # Timeout aumentado para conexiones más estables
DEFAULT_HOST = '127.0.0.1:SSH_PORT_PLACEHOLDER'
MENSAJE_HTML = 'MENSAJE_PLACEHOLDER'

# Límites de recursos
MAX_CONNECTIONS = 500  # Máximo de conexiones concurrentes
CONNECTION_BACKLOG = 100  # Cola de conexiones pendientes

# ═══════════════════════════════════════════════════════════════
# RESPUESTAS HTTP MULTI-RESPONSE
# ═══════════════════════════════════════════════════════════════
RESPONSES = {
    '101': f'HTTP/1.1 101 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 101 Switching Protocols\r\n\r\n',
    '200': f'HTTP/1.1 200 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 200 Connection established\r\n\r\n',
    '201': f'HTTP/1.1 201 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 201 Created\r\n\r\n',
    '202': f'HTTP/1.1 202 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 202 Accepted\r\n\r\n',
    '300': f'HTTP/1.1 300 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 300 Multiple Choices\r\n\r\n',
    '301': f'HTTP/1.1 301 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 301 Moved Permanently\r\n\r\n',
    '302': f'HTTP/1.1 302 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 302 Found\r\n\r\n',
    '400': f'HTTP/1.1 400 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 400 Bad Request\r\n\r\n',
    '401': f'HTTP/1.1 401 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 401 Unauthorized\r\n\r\n',
    '403': f'HTTP/1.1 403 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 403 Forbidden\r\n\r\n',
    '404': f'HTTP/1.1 404 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 404 Not Found\r\n\r\n',
    '500': f'HTTP/1.1 500 {MENSAJE_HTML}\r\nContent-length: 0\r\nConnection: keep-alive\r\n\r\nHTTP/1.1 500 Internal Server Error\r\n\r\n',
}

RESPONSE_PRINCIPAL = 'RESPONSE_PLACEHOLDER'

# ═══════════════════════════════════════════════════════════════
# CONFIGURACIÓN DE LOGGING
# ═══════════════════════════════════════════════════════════════
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# CLASE SERVIDOR MEJORADA
# ═══════════════════════════════════════════════════════════════
class ProxyServer:
    def __init__(self, host, port):
        self.running = False
        self.host = host
        self.port = port
        self.server_socket = None
        self.active_connections = 0
        self.total_connections = 0
        self.lock = threading.Lock()
        
    def start_server(self):
        """Inicia el servidor proxy con configuración optimizada"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            
            # Opciones de socket para mejor rendimiento y estabilidad
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            
            # Configurar TCP keepalive (Linux específico)
            try:
                self.server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 60)
                self.server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
                self.server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 6)
            except (OSError, AttributeError):
                pass  # Ignorar si no está disponible
            
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(CONNECTION_BACKLOG)
            self.server_socket.settimeout(1.0)  # Timeout para poder verificar self.running
            
            self.running = True
            
            logger.info(f"═══════════════════════════════════════════════════")
            logger.info(f"Proxy Directo iniciado correctamente")
            logger.info(f"Puerto escucha: {self.port} -> SSH: {DEFAULT_HOST}")
            logger.info(f"Respuesta principal: HTTP {RESPONSE_PRINCIPAL}")
            logger.info(f"Respuestas disponibles: {', '.join(RESPONSES.keys())}")
            logger.info(f"Máximo conexiones: {MAX_CONNECTIONS}")
            logger.info(f"═══════════════════════════════════════════════════")
            
            while self.running:
                try:
                    client_socket, addr = self.server_socket.accept()
                    
                    # Verificar límite de conexiones
                    with self.lock:
                        if self.active_connections >= MAX_CONNECTIONS:
                            logger.warning(f"Límite de conexiones alcanzado ({MAX_CONNECTIONS})")
                            try:
                                client_socket.send(b'HTTP/1.1 503 Service Unavailable\r\n\r\n')
                                client_socket.close()
                            except:
                                pass
                            continue
                        
                        self.active_connections += 1
                        self.total_connections += 1
                    
                    # Configurar socket del cliente
                    client_socket.settimeout(TIMEOUT)
                    client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                    
                    # Manejar cliente en nuevo hilo
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, addr),
                        daemon=True
                    )
                    client_thread.start()
                    
                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        logger.error(f"Error aceptando conexión: {e}")
                        
        except Exception as e:
            logger.error(f"Error fatal iniciando servidor: {e}")
        finally:
            self.stop_server()
    
    def handle_client(self, client_socket, addr):
        """Maneja la conexión de un cliente con mejor estabilidad"""
        target_socket = None
        try:
            # Recibir petición inicial
            request = b''
            try:
                client_socket.settimeout(5)  # Timeout inicial corto
                while True:
                    chunk = client_socket.recv(BUFLEN)
                    if not chunk:
                        return
                    request += chunk
                    # Detectar fin de headers HTTP
                    if b'\r\n\r\n' in request or b'\n\n' in request:
                        break
                    if len(request) > 16384:  # Límite de seguridad
                        return
            except socket.timeout:
                if len(request) == 0:
                    return
            
            # Decodificar petición
            try:
                request_str = request.decode('utf-8', errors='ignore')
            except:
                return
            
            # Buscar host destino
            host_port = self.find_header(request_str, 'X-Real-Host')
            if not host_port:
                host_port = DEFAULT_HOST
            
            # Verificar contraseña si es necesaria
            if PASS:
                passwd = self.find_header(request_str, 'X-Pass')
                if passwd != PASS:
                    client_socket.send(f'HTTP/1.1 401 {MENSAJE_HTML}\r\n\r\n'.encode())
                    return
            
            # Buscar respuesta personalizada
            custom_response = self.find_header(request_str, 'X-Response')
            if custom_response and custom_response in RESPONSES:
                response_code = custom_response
            else:
                response_code = RESPONSE_PRINCIPAL
            
            # Validar que sea localhost
            if not (host_port.startswith('127.0.0.1') or host_port.startswith('localhost')):
                client_socket.send(f'HTTP/1.1 403 {MENSAJE_HTML}\r\n\r\n'.encode())
                return
            
            # Conectar al destino
            self.method_connect(client_socket, host_port, response_code)
            
        except Exception as e:
            logger.debug(f"Error manejando cliente {addr}: {e}")
        finally:
            try:
                client_socket.close()
            except:
                pass
            if target_socket:
                try:
                    target_socket.close()
                except:
                    pass
            
            with self.lock:
                self.active_connections -= 1
    
    def find_header(self, request, header):
        """Busca un header en la petición HTTP"""
        try:
            lines = request.split('\r\n')
            for line in lines:
                if line.lower().startswith(header.lower() + ':'):
                    return line.split(':', 1)[1].strip()
        except:
            pass
        return ''
    
    def method_connect(self, client_socket, host_port, response_code):
        """Establece la conexión al servidor SSH con mejor manejo de errores"""
        target_socket = None
        try:
            # Parsear host y puerto
            if ':' in host_port:
                host, port = host_port.split(':', 1)
                port = int(port)
            else:
                host = host_port
                port = 22
            
            # Conectar al destino con timeout
            target_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            target_socket.settimeout(10)
            target_socket.connect((host, port))
            
            # Configurar socket para transferencia
            target_socket.settimeout(TIMEOUT)
            target_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            target_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            
            # Enviar respuesta HTTP
            response = RESPONSES.get(response_code, RESPONSES[RESPONSE_PRINCIPAL])
            client_socket.send(response.encode())
            
            # Configurar timeouts para relay
            client_socket.settimeout(TIMEOUT)
            
            # Relay bidireccional de datos
            self.relay_data(client_socket, target_socket)
            
        except socket.timeout:
            logger.debug("Timeout conectando al servidor SSH")
        except ConnectionRefusedError:
            logger.warning(f"Conexión rechazada a {host_port}")
        except Exception as e:
            logger.debug(f"Error en method_connect: {e}")
        finally:
            if target_socket:
                try:
                    target_socket.close()
                except:
                    pass
    
    def relay_data(self, client_socket, target_socket):
        """Relay bidireccional optimizado con mejor manejo de errores"""
        try:
            sockets = [client_socket, target_socket]
            last_activity = time.time()
            
            while True:
                # Verificar timeout de inactividad
                if time.time() - last_activity > TIMEOUT:
                    break
                
                # Esperar datos con select
                try:
                    ready, _, error = select.select(sockets, [], sockets, 5.0)
                except (ValueError, OSError):
                    break
                
                if error:
                    break
                
                if not ready:
                    continue
                
                for sock in ready:
                    try:
                        data = sock.recv(BUFLEN)
                        if not data:
                            return
                        
                        last_activity = time.time()
                        
                        # Enviar datos al socket opuesto
                        if sock is client_socket:
                            target_socket.sendall(data)
                        else:
                            client_socket.sendall(data)
                            
                    except socket.timeout:
                        continue
                    except (ConnectionResetError, BrokenPipeError, OSError):
                        return
                    except Exception as e:
                        logger.debug(f"Error en relay: {e}")
                        return
                        
        except Exception as e:
            logger.debug(f"Error en relay_data: {e}")
    
    def stop_server(self):
        """Detiene el servidor correctamente"""
        logger.info("Deteniendo servidor...")
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass
        logger.info(f"Servidor detenido. Total conexiones procesadas: {self.total_connections}")

# ═══════════════════════════════════════════════════════════════
# MANEJADOR DE SEÑALES
# ═══════════════════════════════════════════════════════════════
def signal_handler(sig, frame):
    logger.info("\nSeñal de terminación recibida")
    sys.exit(0)

# ═══════════════════════════════════════════════════════════════
# PUNTO DE ENTRADA PRINCIPAL
# ═══════════════════════════════════════════════════════════════
if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        server = ProxyServer(LISTENING_ADDR, LISTENING_PORT)
        server.start_server()
    except Exception as e:
        logger.error(f"Error fatal: {e}")
        sys.exit(1)
PYTHON_SCRIPT

    # Reemplazar placeholders con valores reales
    sed -i "s/PORT_PLACEHOLDER/${puerto}/g" /etc/VPS-AGN/protocols/PDirect_${puerto}.py
    sed -i "s/SSH_PORT_PLACEHOLDER/${puerto_ssh}/g" /etc/VPS-AGN/protocols/PDirect_${puerto}.py
    sed -i "s/RESPONSE_PLACEHOLDER/${respuesta_principal}/g" /etc/VPS-AGN/protocols/PDirect_${puerto}.py
    sed -i "s/MENSAJE_PLACEHOLDER/${mensaje_html}/g" /etc/VPS-AGN/protocols/PDirect_${puerto}.py
    
    chmod +x /etc/VPS-AGN/protocols/PDirect_${puerto}.py
}

#====================================================================
# VERIFICAR SI UN PUERTO ESTÁ DISPONIBLE
#====================================================================
check_port_available() {
    local port=$1
    if ss -tlnp 2>/dev/null | grep -q ":$port " || netstat -tlnp 2>/dev/null | grep -q ":$port "; then
        return 1  # Puerto ocupado
    else
        return 0  # Puerto disponible
    fi
}

#====================================================================
# DETECTAR PUERTO SSH/DROPBEAR ACTIVO
#====================================================================
check_ssh_port() {
    # Verificar puertos comunes de Dropbear
    for port in 90 109 110 143; do
        if ss -tlnp 2>/dev/null | grep -q ":$port.*dropbear" || \
           netstat -tlnp 2>/dev/null | grep -q ":$port.*dropbear"; then
            echo "$port"
            return
        fi
    done
    
    # Verificar puerto 22 (SSH estándar)
    if ss -tlnp 2>/dev/null | grep -q ":22 " || netstat -tlnp 2>/dev/null | grep -q ":22 "; then
        echo "22"
        return
    fi
    
    # Default
    echo "22"
}

#====================================================================
# FUNCIÓN PRINCIPAL
#====================================================================
main() {
    clear
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}║  ${cor[3]}PROXY DIRECTO MULTI-RESPONSE MEJORADO${cor[4]}           ║"
    echo -e "${cor[4]}║  ${cor[0]}Por JuanitoProSniff - Versión Optimizada${cor[4]}        ║"
    echo -e "${cor[4]}║  ${cor[0]}Alta Estabilidad | Multi-Usuario | Ubuntu 20-24${cor[4]} ║"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
    echo ""
    
    # Instalar dependencias
    instalar_dependencias
    
    # Configuración de puertos
    declare -A PUERTOS_CONFIG=(
        [80]="101"
        [8080]="101"
        [8088]="101"
        [8280]="101"
        [8880]="101"
        [2052]="200"
        [2082]="200"
        [2086]="200"
        [2095]="200"
    )
    
    # Detectar puerto SSH/Dropbear
    PUERTO_SSH=$(check_ssh_port)
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║ Puerto SSH/Dropbear detectado: ${cor[4]}$PUERTO_SSH${cor[3]}       ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo ""
    
    # Detener procesos previos
    echo -e "${cor[3]}→ Deteniendo procesos previos..."
    pkill -9 -f "PDirect_" 2>/dev/null
    sleep 1
    screen -ls | grep -E "pydirect-" | cut -d. -f1 | awk '{print $1}' | xargs -I {} screen -X -S {} quit 2>/dev/null
    sleep 1
    echo -e "${cor[4]}  ✓ Procesos anteriores detenidos\n"
    
    # Configurar cada puerto
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║       Configurando Proxies...              ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    
    local active_count=0
    local skipped_count=0
    
    for puerto in $(echo "${!PUERTOS_CONFIG[@]}" | tr ' ' '\n' | sort -n); do
        respuesta_principal="${PUERTOS_CONFIG[$puerto]}"
        
        if check_port_available $puerto; then
            echo -e "${cor[3]}→ Puerto ${cor[4]}$puerto${cor[3]} - Respuesta principal: ${cor[4]}$respuesta_principal"
            
            # Crear script Python
            create_python_proxy $puerto $PUERTO_SSH $respuesta_principal
            
            # Iniciar en screen
            screen -dmS pydirect-$puerto python3 /etc/VPS-AGN/protocols/PDirect_${puerto}.py
            
            # Verificar inicio
            sleep 0.5
            if pgrep -f "PDirect_${puerto}.py" > /dev/null; then
                echo -e "${cor[4]}  ✓ Proxy iniciado correctamente en puerto $puerto\n"
                ((active_count++))
            else
                echo -e "${cor[2]}  ✗ Error iniciando proxy en puerto $puerto\n"
            fi
        else
            echo -e "${cor[2]}✗ Puerto $puerto ya está en uso, omitiendo...\n"
            ((skipped_count++))
        fi
    done
    
    # Mostrar resumen final
    echo ""
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}║         ${cor[0]}CONFIGURACIÓN COMPLETADA EXITOSAMENTE${cor[4]}         ║"
    echo -e "${cor[4]}║                                                      ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
    echo ""
    echo -e "${cor[0]}Server IP:         ${cor[4]}$(meu_ip)"
    echo -e "${cor[0]}Puerto SSH usado:  ${cor[4]}$PUERTO_SSH"
    echo -e "${cor[0]}Mensaje HTML:      ${cor[4]}JuanitoProSniff©"
    echo -e "${cor[0]}Proxies activos:   ${cor[4]}$active_count/${#PUERTOS_CONFIG[@]}"
    [[ $skipped_count -gt 0 ]] && echo -e "${cor[0]}Puertos omitidos:  ${cor[2]}$skipped_count"
    echo ""
    
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║     Respuestas por Puerto Configuradas    ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[0]}Puertos ${cor[4]}80, 8080, 8088, 8280, 8880${cor[0]}: Respuesta principal ${cor[4]}101"
    echo -e "${cor[0]}Puertos ${cor[4]}2052, 2082, 2086, 2095${cor[0]}:     Respuesta principal ${cor[4]}200"
    echo ""
    
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║           Puertos Activos                  ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    for puerto in $(echo "${!PUERTOS_CONFIG[@]}" | tr ' ' '\n' | sort -n); do
        if pgrep -f "PDirect_${puerto}.py" > /dev/null; then
            respuesta_principal="${PUERTOS_CONFIG[$puerto]}"
            echo -e "${cor[4]}✓ Puerto $puerto${cor[0]} → Principal: ${cor[4]}$respuesta_principal${cor[0]} → SSH: ${cor[4]}$PUERTO_SSH"
        fi
    done
    echo ""
    
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║        Características Mejoradas           ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[4]}✓${cor[0]} Conexiones ultra estables con timeouts optimizados"
    echo -e "${cor[4]}✓${cor[0]} Soporte para hasta 500 usuarios concurrentes por puerto"
    echo -e "${cor[4]}✓${cor[0]} Reconexión automática y manejo robusto de errores"
    echo -e "${cor[4]}✓${cor[0]} TCP keepalive activado para evitar desconexiones"
    echo -e "${cor[4]}✓${cor[0]} Buffer optimizado (8KB) para mejor rendimiento"
    echo -e "${cor[4]}✓${cor[0]} Logging detallado para monitoreo"
    echo -e "${cor[4]}✓${cor[0]} Multi-response: 12 códigos HTTP disponibles"
    echo -e "${cor[4]}✓${cor[0]} Mensaje personalizado en todas las respuestas"
    echo ""
    
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║           Uso de Headers                   ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[0]}• X-Response: CODIGO → Usa respuesta personalizada"
    echo -e "${cor[0]}  Ejemplo: ${cor[4]}X-Response: 404${cor[0]} (respuesta 404)"
    echo -e "${cor[0]}• Códigos disponibles: ${cor[4]}101, 200, 201, 202, 300, 301,"
    echo -e "${cor[0]}                        ${cor[4]}302, 400, 401, 403, 404, 500"
    echo ""
    
    echo -e "${cor[3]}╔════════════════════════════════════════════╗"
    echo -e "${cor[3]}║        Comandos de Monitoreo               ║"
    echo -e "${cor[3]}╚════════════════════════════════════════════╝${cor[0]}"
    echo -e "${cor[0]}Ver todos los proxies:    ${cor[4]}screen -ls"
    echo -e "${cor[0]}Conectar a un proxy:      ${cor[4]}screen -r pydirect-PUERTO"
    echo -e "${cor[0]}Salir sin cerrar screen:  ${cor[4]}Ctrl+A luego D"
    echo -e "${cor[0]}Ver procesos activos:     ${cor[4]}ps aux | grep PDirect"
    echo -e "${cor[0]}Ver puertos escuchando:   ${cor[4]}ss -tlnp | grep python"
    echo ""
    
    echo -e "${cor[4]}╔══════════════════════════════════════════════════════╗"
    echo -e "${cor[4]}║  ${cor[0]}Instalación completada - Sistema listo para usar${cor[4]}  ║"
    echo -e "${cor[4]}╚══════════════════════════════════════════════════════╝${cor[0]}"
}

# Ejecutar función principal
main