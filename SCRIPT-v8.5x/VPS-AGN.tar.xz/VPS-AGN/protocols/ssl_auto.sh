#!/bin/bash
#25/01/2021 by @KhaledAGN modificado por JuanitoProSniff
#SSL Auto-Install - Puertos: 440, 441, 442, 443, 444, 445
clear
clear
SCPdir="/etc/VPS-AGN"
SCPfrm="${SCPdir}/tools" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="${SCPdir}/protocols"&& [[ ! -d ${SCPinst} ]] && exit
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )
dirapache="/usr/local/lib/ubuntn/apache/ver" && [[ ! -d ${dirapache} ]] && exit

mportas () {
unset portas
portas_var=$(lsof -V -i tcp -P -n | grep -v "ESTABLISHED" |grep -v "COMMAND" | grep "LISTEN")
while read port; do
var1=$(echo $port | awk '{print $1}') && var2=$(echo $port | awk '{print $9}' | awk -F ":" '{print $2}')
[[ "$(echo -e $portas|grep "$var1 $var2")" ]] || portas+="$var1 $var2\n"
done <<< "$portas_var"
i=1
echo -e "$portas"
}

fun_bar () {
comando="$1"
 _=$(
$comando > /dev/null 2>&1
) & > /dev/null
pid=$!
while [[ -d /proc/$pid ]]; do
echo -ne " \033[1;33m["
   for((i=0; i<20; i++)); do
   echo -ne "\033[1;31m##"
   sleep 0.1
   done
echo -ne "\033[1;33m]"
sleep 1s
echo
tput cuu1
tput dl1
done
echo -e " \033[1;33m[\033[1;31m########################################\033[1;33m] - \033[1;32m OK \033[0m"
sleep 1s
}

check_ssl_port() {
    # Verificar si puerto 110 está activo
    if [[ $(mportas|grep 110|head -1) ]]; then
        echo "110"
    else
        echo "22"
    fi
}

ssl_auto_install() {
    # Puertos SSL predefinidos
    SSL_PORTS=(440 441 442 443 444 445)
    
    echo -e "\033[1;32m   SSL AUTO-INSTALLER | BY JUANITOPROSNIFF"
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[0]}Configurando SSL automáticamente..."
    echo ""
    
    # Determinar puerto local
    LOCAL_PORT=$(check_ssl_port)
    echo -e "${cor[3]}Puerto local detectado: ${cor[4]}$LOCAL_PORT"
    
    # Detener stunnel existente si está activo
    if [[ $(mportas|grep stunnel4|head -1) ]]; then
        echo -e "${cor[3]}Deteniendo stunnel existente..."
        service stunnel4 stop > /dev/null 2>&1
        apt-get purge stunnel4 -y > /dev/null 2>&1
        echo -e "${cor[4]}✓ Stunnel anterior removido"
    fi
    
    echo -e "${cor[3]}Instalando stunnel4..."
    fun_bar "apt-get install stunnel4 -y"
    apt-get install stunnel4 -y > /dev/null 2>&1
    
    # Crear certificados SSL
    echo -e "${cor[3]}Generando certificados SSL..."
    openssl genrsa -out stunnel.key 2048 > /dev/null 2>&1
    
    # Crear certificado automáticamente con información predeterminada
    (echo "CO" ; echo "Bolivar" ; echo "Cartagena" ; echo "JuanitoProSniff" ; echo "VPS-AGN" ; echo "ssl.juanitoprosniff.com" ; echo "admin@juanitoprosniff.com") | openssl req -new -key stunnel.key -x509 -days 1000 -out stunnel.crt > /dev/null 2>&1
    
    cat stunnel.crt stunnel.key > stunnel.pem 
    mv stunnel.pem /etc/stunnel/
    
    # Crear configuración stunnel con múltiples puertos
    echo -e "${cor[3]}Configurando múltiples puertos SSL..."
    
    cat > /etc/stunnel/stunnel.conf << EOF
client = no

EOF
    
    # Agregar cada puerto SSL
    for i in "${!SSL_PORTS[@]}"; do
        port=${SSL_PORTS[$i]}
        section_name="SSL$((i+1))"
        
        # Verificar que el puerto no esté en uso
        if [[ ! $(mportas|grep -w "$port") ]]; then
            echo -e "${cor[4]}✓ Configurando puerto SSL $port"
            cat >> /etc/stunnel/stunnel.conf << EOF
[$section_name]
cert = /etc/stunnel/stunnel.pem
accept = $port
connect = 127.0.0.1:$LOCAL_PORT

EOF
        else
            echo -e "${cor[2]}✗ Puerto $port ocupado, omitiendo..."
        fi
    done
    
    # Habilitar stunnel
    sed -i 's/ENABLED=0/ENABLED=1/g' /etc/default/stunnel4
    
    # Reiniciar servicio
    echo -e "${cor[3]}Iniciando servicios SSL..."
    service stunnel4 restart > /dev/null 2>&1
    
    # Limpiar archivos temporales
    rm -rf /root/stunnel.crt > /dev/null 2>&1
    rm -rf /root/stunnel.key > /dev/null 2>&1
    
    # Mostrar resultado
    echo ""
    echo -e "${cor[4]}=================================================="
    echo -e "${cor[4]}SSL CONFIGURADO EXITOSAMENTE"
    echo -e "${cor[0]}Puerto local: ${cor[4]}$LOCAL_PORT"
    echo -e "${cor[0]}Puertos SSL configurados:"
    
    sleep 2
    active_ssl=0
    for port in "${SSL_PORTS[@]}"; do
        if netstat -tlnp 2>/dev/null | grep -q ":$port " || ss -tlnp 2>/dev/null | grep -q ":$port "; then
            echo -e "${cor[4]}✓ Puerto SSL $port - ACTIVO"
            ((active_ssl++))
        else
            if [[ ! $(mportas|grep -w "$port") ]]; then
                echo -e "${cor[2]}✗ Puerto SSL $port - INACTIVO"
            fi
        fi
    done
    
    echo ""
    echo -e "${cor[4]}Total de puertos SSL activos: $active_ssl"
    echo -e "${cor[3]}Certificado: ssl.juanitoprosniff.com"
    echo -e "${cor[3]}Válido por: 1000 días"
    echo -e "${cor[4]}=================================================="
    
    echo ""
    echo -e "${cor[3]}INFORMACIÓN DE CONEXIÓN SSL:"
    for port in "${SSL_PORTS[@]}"; do
        if netstat -tlnp 2>/dev/null | grep -q ":$port " || ss -tlnp 2>/dev/null | grep -q ":$port "; then
            echo -e "${cor[0]}  Puerto SSL $port -> Puerto local $LOCAL_PORT"
        fi
    done
    
    echo ""
    echo -e "${cor[3]}Para verificar el estado:"
    echo -e "${cor[0]}  service stunnel4 status"
    echo -e "${cor[0]}  netstat -tlnp | grep stunnel"
}

# Ejecutar instalación automática
ssl_auto_install