#!/usr/bin/env bash
#
# Script simplificado - AGN UDP
# (c) 2025 Juanitoprosniff
#

set -e

# Rutas
MANAGER_SCRIPT="/etc/VPS-AGN/protocols/agnudp_manager.sh"
INSTALLER_SCRIPT="/etc/VPS-AGN/protocols/install_agnudp.sh"

mostrar_banner() {
    clear
    echo "============================================="
    echo "     SCRIPT VPS - AGN UDP SIMPLE V2025       "
    echo "============================================="
    echo "  (c) 2025 Juanitoprosniff                   "
    echo "============================================="
    echo
}

mostrar_menu() {
    echo "Seleccione una opción:"
    echo "1. Abrir Manager"
    echo "2. Instalar UDP"
    echo "3. Salir"
    echo
    echo -n "Ingrese su opción [1-3]: "
}

abrir_manager() {
    bash "$MANAGER_SCRIPT"
}

instalar_udp() {
    bash "$INSTALLER_SCRIPT"
}

main() {
    while true; do
        mostrar_banner
        mostrar_menu
        read -r opcion
        case "$opcion" in
            1) abrir_manager ;;
            2) instalar_udp ;;
            3) exit 0 ;;
            *) echo "Opción inválida" ;;
        esac
        echo
        read -p "Presione Enter para continuar..."
    done
}

main "$@"
